/* ============================================================
   WattTrack v5 — EV şarj harcama takibi
   Veriler yalnızca cihazda (IndexedDB / Dexie.js) saklanır.
   Tek dış bağlantı (opsiyonel): döviz kuru için frankfurter API.
   ============================================================ */

const db = new Dexie('watttrack');
db.version(1).stores({
  sessions: '++id, tarih, firma, tip, aracId',
  vehicles: '++id, ad',
  settings: 'key'
});
// v2: araç giderleri (vergi, sigorta, bakım…) — sahip olma maliyeti için
db.version(2).stores({
  sessions: '++id, tarih, firma, tip, aracId',
  vehicles: '++id, ad',
  settings: 'key',
  expenses: '++id, tarih, tur, aracId'
});
const EXP_TYPES = ['tax', 'insurance', 'maintenance', 'tire', 'inspection',
                   'repair', 'parking', 'equipment', 'other'];
const EXP_ICON = {tax: '🧾', insurance: '🛡️', maintenance: '🔧', tire: '🛞',
  inspection: '✅', repair: '🛠️', parking: '🅿️', equipment: '🔌', other: '📦'};

const AVATAR_COLORS = ['#1C8742', '#007DAA', '#C87B00', '#A54C8B', '#C25C5F'];
const MI = 1.60934;
const APP_VERSION = 'v19';
const APP_DATE = '26.07.2026';

// ---------- Çeviriler ----------
const T = {
tr:{navStats:'İstatistik',statsTitle:'İstatistikler',ice1:'Yakıtlı 1 {u}',unitCostTitle:'Birim maliyet — EV ve Yakıtlı yan yana',tcoExpEv:'EV sabit giderleri (Aracım)',tcoExpIce:'Yakıtlı sabit gider (döneme oranlı)',tco1kmIce:'Yakıtlı 1 {u} (gider dahil)',tcoExplain:'EV sabit giderleri, Aracım sekmesine girdiğin vergi, sigorta, bakım gibi kalemlerdir. Yakıtlı tarafta, yukarıda girdiğin yıllık sabit gider izlenen döneme oranlanır — iki araç aynı dönemde karşılaştırılır.',totalCostAll:'Toplam gider (şarj + sabit)',fixedExpTotal:'Sabit giderler toplamı',expChart:'Sabit gider grafiği',prorateLbl:'Yıllık giderleri (vergi, sigorta) izlenen döneme oranla',prorateNote:'Yıllık kalemler dönem oranıyla (%{p}) hesaba katıldı; gerçek ödenen toplam {r}.',exp_tax:'Vergi (MTV)',exp_insurance:'Sigorta / Kasko',exp_maintenance:'Bakım / Servis',exp_tire:'Lastik',exp_inspection:'Muayene',exp_repair:'Onarım / Hasar',exp_parking:'Otopark / Otoyol',exp_equipment:'Ekipman (ev şarj cihazı vb.)',exp_other:'Diğer',otherTypePh:'Başlık yaz — örn. Aksesuar, Araç yıkama',addExpense:'Gider ekle',editExpense:'Gideri düzenle',expType:'Gider türü',expenses:'Araç giderleri',expByCat:'Gider dağılımı',expTotal:'Giderler toplamı',expAmount:'Tutar',noteLbl:'Not',amountNeeded:'Tutar gir',noExpenses:'Henüz gider yok. Vergi, sigorta ve bakım tutarlarını ekleyerek gerçek maliyeti gör.',tcoTitle:'Toplam sahip olma maliyeti (şarj + giderler)',tcoEv:'EV toplam (şarj + gider)',tcoIce:'Yakıtlı toplam (gider dahil)',tcoSaved:'Gider dahil toplam kazanç',tco1km:'EV 1 {u} (gider dahil)',tcoNote:'İzlenen dönem {d} gün. Yakıtlı aracın sabit gideri bu döneme oranlandı: {f}.',nonFuelTitle:'Yakıt dışı gider kıyaslaması',nonFuelKm:'{u} başına yakıt dışı gider',nonFuel100:'100 {u} başına yakıt dışı gider',nonFuelYear:'Yıllık yakıt dışı gider',nonFuelKwh:'kWh başına yakıt dışı gider',nonFuelDiffYear:'Yıllık yakıt dışı gider farkı',nonFuelChart:'Yıllık yakıt dışı gider (EV / Yakıtlı)',iceShort:'Yakıtlı',chargePower:'Ort. şarj gücü',yearlyCompare:'Yıllık karşılaştırma',yearlySpendLbl:'Toplam harcama (bu yıl)',yearlyKwhLbl:'Enerji (bu yıl)',yearlyPriceLbl:'kWh fiyatı (bu yıl)',weekdayDist:'Haftanın günlerine göre dağılım',vsLastYear:'geçen yıla göre',iceFixHint:'İsteğe bağlı. Benzer bir yakıtlı aracın yıllık vergi, sigorta ve bakım toplamını yaz — adil kıyas için kendi giderlerinle karşılaştırılır.',ev1:'EV 1 {u} ({x})',supportNote:'Bu uygulama tamamen ücretsiz ve reklamsız olarak geliştirilmiştir. Projeye destek olmak veya bir kahve ısmarlamak isterseniz GitHub sayfamıza göz atabilirsiniz.',version:'Sürüm',contactDev:'Soru ve katkı',privacy:'Gizlilik Politikası',rateApp:'Play Store\u0027da Değerlendir',supportDev:'GitHub Proje Sayfası',kwhHint:'Sol kutu tam kısım, sağ kutu 2 haneli ondalık — 45 , 27 = 45,27 kWh. Sadece rakam girilir.',distFromOdo:'Mesafe kaynağı: kilometre sayacı (araç bilgilerinden)',distFromRecords:'Mesafe kaynağı: kayıtlardaki sürüş mesafeleri',back:'← Geri',changeCar:'Aracı değiştir',navVehicle:'Aracım',vehicleTitle:'Aracım',odoAsk:'Aracın güncel kilometresi (sayaç)',odometer:'Kilometre sayacı',odoNow:'Araç sayacı',odoTracked:'Başlangıçtan beri yapılan',odoPrompt:'Güncel sayaç ({u}):',odoStartPrompt:'Başlangıç/alım sayacı ({u}):',odoSaved:'Kilometre güncellendi',theme:'Görünüm',themeLight:'Açık',themeDark:'Koyu',spendChart:'Harcama grafiği',cumTitle:'Bugüne kadar: aynı km yakıtlıyla gidilseydi',totalDist:'Toplam mesafe',evSpent:'EV toplam (net)',iceWould:'Yakıtlıyla olurdu',totalSaved:'Toplam kazanç',evLine:'EV (gerçek)',iceLine:'Yakıtlı (aynı km)',archived:'Arşiv (satılan/kullanılmayan)',archivedTag:'arşivde — kayıtları korunuyor',archivedToast:'Araç arşive taşındı, kayıtları korunuyor',restore:'Geri al',newBank:'+ Yeni banka ekle…',newBankPrompt:'Banka adı:',importAllDup:'Bu yedekteki tüm kayıtlar zaten mevcut — hiçbir şey eklenmedi.',importPartial:'{n} yeni kayıt eklendi, {d} mükerrer atlandı',netPaid:'Ödenen (net)',typeSplit:'Şarj tipi dağılımı (kWh)',detailStats:'Detay istatistikler',avgDuration:'Ort. şarj süresi',avgSocRange:'Ort. şarj aralığı',topBanks:'Bankalar (indirim kazancı)',topLocations:'En çok şarj edilen lokasyonlar',bankCountries:'Banka Ülkelerim',bankCountriesD:'Kartların hangi ülkelerden ise seç — formdaki banka listesi bunlara göre gelir. Şarj ettiğin ülke değişse de bankaların değişmez.',addCountry:'+ Ülke ekle',prevPeriod:'önceki döneme göre',navHome:'Ana Sayfa',navHistory:'Geçmiş',navCompare:'Kıyasla',navSettings:'Ayarlar',
week:'Hafta',month:'Ay',year:'Yıl',
periodWeek:'Bu hafta toplam',periodMonth:'Bu ay toplam',periodYear:'Bu yıl toplam',
savings:'tasarruf',avgPerKwh:'kWh başı',netLbl:'net',grossLbl:'indirimsiz',
grossTotal:'İndirimsiz toplam',cost100:'100 {u}',
totalKwhP:'Enerji (kWh)',sessionsCompanies:'Şarj / Firma',totalDiscP:'Alınan indirim',
freeCount:'Ücretsiz şarj',weeklySpend:'Haftalık harcama',monthlyTotals:'Aylık Harcama',
firmDist:'Firma dağılımı',recentCharges:'Son şarjlar',viewAll:'Tümü',allVehicles:'Tüm araçlar',
historyTitle:'Geçmiş',allYears:'Tüm yıllar',allFirms:'Tüm firmalar',allTypes:'Tüm tipler',free:'Ücretsiz',
compareTitle:'Yakıtlı Araçla Kıyasla',fuelType:'Diğer aracın yakıt tipi',
petrol:'Benzin',diesel:'Dizel',hybrid:'Hibrit',
hybridNote:'Şarj edilmeyen (tam) hibrit de lt/100km ile ölçülür — sadece tüketimi düşüktür (~4-5 lt). Şarjlı hibrit (PHEV) için ortalama karma tüketimi gir.',
fuelPrice:'Yakıt fiyatı ({s}/lt)',fuelCons:'Tüketim (lt/100km)',calc:'Kıyasla',
evCost:'EV 100 {u} (net)',evCostG:'EV 100 {u} (indirimsiz)',iceCost:'Yakıtlı 100 {u}',
discEffect:'İndirim etkisi / 100 {u}',perUnitSaving:'{u} başına kazanç',
per100:'100 {u} başına {v} kazanç',savingByMonth:'Aylara göre kazanç',
compareNote:'Grafik, kayıtlardaki sürüş mesafesine göre aynı yolu yakıtlı araçla gitseydin aradaki farkı gösterir. Mesafe girilmiş kayıtlar hesaba katılır; kazanç net ödenen üzerinden hesaplanır.',
needData:'Hesap için mesafe girilmiş şarj kaydı gerekli',
settingsTitle:'Ayarlar',regionSection:'Ülke ve Bölge',country:'Ülke',currency:'Para Birimi',
unit:'Mesafe Birimi',language:'Dil',vehicles:'Araçlarım',addVehicle:'+ Araç ekle',
defaultHint:'★ varsayılan · km✎ kilometre · 📷 fotoğraf · × arşivle',
formSection:'Kayıt Formu',advAlways:'Gelişmiş alanlar hep açık',
advAlwaysD:'Banka, süre, lokasyon ve şarj aralığı formda açık gelsin',
dataSection:'Veri',exportJson:'Dışa Aktar (JSON)',exportCsv:'Dışa Aktar (CSV — Excel/Power BI)',
importJson:'Yedeği Geri Yükle (JSON)',reset:'Verileri Sıfırla',about:'Hakkında',
aboutText:'WattTrack tamamen ücretsizdir ve reklam içermez. Tüm verileriniz yalnızca bu cihazda saklanır; hiçbir sunucuya gönderilmez, üçüncü kişilerle paylaşılmaz ve satılmaz. Hesap/üyelik yoktur. Tek ağ kullanımı: yurt dışı kayıtlarda döviz kuru (yalnız para birimi kodları) ve 📍 kullanınca konum servisleri. Cihazlar arası taşıma için JSON yedeğini kullanın.',
addTitle:'Yeni Şarj Kaydı',editTitle:'Kaydı Düzenle',date:'Tarih',chargeType:'Şarj Tipi',
company:'Ev ya da Şarj Firması',homeChip:'Ev',other:'Diğer…',kwh:'Enerji (kWh)',
distance:'Sürülen mesafe ({u})',
freeCharge:'Ücretsiz şarj',freeChargeD:'Kampanya, ev güneş vb. — tutar 0 kaydedilir',
amount:'Tutar — indirim öncesi ({s})',discountType:'İndirim Türü',amountType:'Tutar',percentType:'Yüzde (%)',
bank:'Banka',vehicle:'Araç',advanced:'+ Gelişmiş',advancedHide:'− Gelişmişi gizle',
duration:'Şarj süresi',hours:'saat',minutes:'dakika',location:'Lokasyon',
socRange:'Şarj aralığı % (başlangıç → bitiş)',note:'Not',
rateLbl:'Kur (1 {f} = ? {b})',
rateNote:'Yurt dışı harcama, girilen kurla {b} cinsine çevrilerek istatistiklere katılır. Kur bulunamazsa elle gir.',
rateAuto:'Kur otomatik alındı ({d})',rateNeeded:'Yurt dışı kayıt için kur gerekli',
gpsFail:'Konum alınamadı — izin verildiğinden emin ol',
formError:'Firma, kWh ve tutar gerekli',save:'Kaydet',
deleteAsk:'Bu kayıt silinsin mi?',deleted:'Kayıt silindi',saved:'Kayıt eklendi',updated:'Kayıt güncellendi',
obWelcome:'Hoş geldin!',obCountryQ:'Hangi ülkede şarj oluyorsun? Para birimi ve mesafe birimini buna göre ayarlayalım.',
obCarQ:'Aracını seç',obCarSub:'Marka veya model yaz — yıl ve donanıma göre farklı batarya sürümlerini ayırt et.',
searchCar:'ör. Model Y, Togg, Torres…',continue:'Devam',skip:'Atla',start:'Başla',
battery:'Batarya',arch:'Mimari',dcMax:'Maks DC',acMax:'AC',range:'Menzil (WLTP)',
addPhoto:'📷 Fotoğraf ekle',changePhoto:'📷 Fotoğrafı değiştir',
customAdd:'"{q}" adıyla özel araç ekle',vehicleAdded:'Araç eklendi',photoAdded:'Fotoğraf eklendi',add:'Ekle',
wipeAsk1:'TÜM kayıtlar, araçlar ve ayarlar silinecek. Emin misin?',wipeAsk2:'Geri alınamaz. Silinsin mi?',
wiped:'Tüm veriler silindi',imported:'Yedek geri yüklendi',
importFail:'Dosya geçerli bir WattTrack yedeği değil',importAsk:'kayıt içe aktarılacak. Birleştirilsin mi?',
jsonDone:'JSON yedek indirildi',csvDone:'CSV indirildi',noData:'Henüz kayıt yok',sessions:'şarj'},

en:{navStats:'Stats',statsTitle:'Statistics',ice1:'Fuel per 1 {u}',unitCostTitle:'Unit cost — EV and fuel side by side',tcoExpEv:'EV fixed expenses (My Vehicle)',tcoExpIce:'Fuel car fixed cost (prorated)',tco1kmIce:'Fuel per 1 {u} (with expenses)',tcoExplain:'EV fixed expenses are the tax, insurance and maintenance items you entered in My Vehicle. On the fuel side, the yearly fixed cost you entered above is prorated to the tracked period — both cars are compared over the same period.',totalCostAll:'Total cost (charging + fixed)',fixedExpTotal:'Fixed expenses total',expChart:'Fixed expense chart',prorateLbl:'Prorate yearly expenses (tax, insurance) to the tracked period',prorateNote:'Yearly items counted at {p}% of the period; actually paid in total {r}.',exp_tax:'Tax',exp_insurance:'Insurance',exp_maintenance:'Maintenance / Service',exp_tire:'Tires',exp_inspection:'Inspection',exp_repair:'Repair / Damage',exp_parking:'Parking / Tolls',exp_equipment:'Equipment (home charger etc.)',exp_other:'Other',otherTypePh:'Type a title — e.g. Accessories, Car wash',addExpense:'Add expense',editExpense:'Edit expense',expType:'Expense type',expenses:'Vehicle expenses',expByCat:'Expenses by category',expTotal:'Total expenses',expAmount:'Amount',noteLbl:'Note',amountNeeded:'Enter an amount',noExpenses:'No expenses yet. Add tax, insurance and maintenance to see your true cost.',tcoTitle:'Total cost of ownership (charging + expenses)',tcoEv:'EV total (charging + expenses)',tcoIce:'Fuel car total (with expenses)',tcoSaved:'Total saved incl. expenses',tco1km:'EV per 1 {u} (with expenses)',tcoNote:'Tracked period {d} days. Fixed cost of the fuel car prorated for this period: {f}.',nonFuelTitle:'Non-fuel expense comparison',nonFuelKm:'Non-fuel cost per {u}',nonFuel100:'Non-fuel cost per 100 {u}',nonFuelYear:'Yearly non-fuel cost',nonFuelKwh:'Non-fuel cost per kWh',nonFuelDiffYear:'Yearly non-fuel cost difference',nonFuelChart:'Yearly non-fuel cost (EV / Fuel)',iceShort:'Fuel',chargePower:'Avg charging power',yearlyCompare:'Yearly comparison',yearlySpendLbl:'Total spend (this year)',yearlyKwhLbl:'Energy (this year)',yearlyPriceLbl:'Price per kWh (this year)',weekdayDist:'By day of week',vsLastYear:'vs last year',iceFixHint:'Optional. Enter the yearly tax, insurance and maintenance total of a comparable fuel car for a fair comparison.',ev1:'EV per 1 {u} ({x})',supportNote:'This app is developed completely free and ad-free. If you would like to support the project or buy a coffee, feel free to visit our GitHub page.',version:'Version',contactDev:'Questions & contributions',privacy:'Privacy Policy',rateApp:'Rate on Play Store',supportDev:'GitHub Project Page',kwhHint:'Left box whole part, right box 2-digit decimals — 45 , 27 = 45.27 kWh. Digits only.',distFromOdo:'Distance source: odometer (from vehicle info)',distFromRecords:'Distance source: per-record distances',back:'← Back',changeCar:'Change vehicle',navVehicle:'My Vehicle',vehicleTitle:'My Vehicle',odoAsk:'Current odometer reading',odometer:'Odometer',odoNow:'Odometer',odoTracked:'Driven since start',odoPrompt:'Current odometer ({u}):',odoStartPrompt:'Starting/purchase odometer ({u}):',odoSaved:'Odometer updated',theme:'Appearance',themeLight:'Light',themeDark:'Dark',spendChart:'Spending chart',cumTitle:'To date: same km with a fuel car',totalDist:'Total distance',evSpent:'EV total (net)',iceWould:'Would cost (fuel)',totalSaved:'Total saved',evLine:'EV (actual)',iceLine:'Fuel (same km)',archived:'Archive (sold/unused)',archivedTag:'archived — records kept',archivedToast:'Vehicle archived, its records are kept',restore:'Restore',newBank:'+ Add new bank…',newBankPrompt:'Bank name:',importAllDup:'All records in this backup already exist — nothing was added.',importPartial:'{n} new records added, {d} duplicates skipped',netPaid:'Paid (net)',typeSplit:'Charge type split (kWh)',detailStats:'Detail statistics',avgDuration:'Avg charge time',avgSocRange:'Avg SoC range',topBanks:'Banks (discount savings)',topLocations:'Most charged locations',bankCountries:'My Bank Countries',bankCountriesD:'Pick the countries your cards are from — the bank list in the form follows these. Your banks don’t change when the charging country does.',addCountry:'+ Add country',prevPeriod:'vs previous period',navHome:'Home',navHistory:'History',navCompare:'Compare',navSettings:'Settings',
week:'Week',month:'Month',year:'Year',
periodWeek:'This week total',periodMonth:'This month total',periodYear:'This year total',
savings:'saved',avgPerKwh:'Per kWh',netLbl:'net',grossLbl:'w/o discount',
grossTotal:'Total before discounts',cost100:'Per 100 {u}',
totalKwhP:'Energy (kWh)',sessionsCompanies:'Sessions / Companies',totalDiscP:'Discounts received',
freeCount:'Free charges',weeklySpend:'Weekly spend',monthlyTotals:'Monthly Spend',
firmDist:'By company',recentCharges:'Recent charges',viewAll:'View all',allVehicles:'All vehicles',
historyTitle:'History',allYears:'All years',allFirms:'All companies',allTypes:'All types',free:'Free',
compareTitle:'Compare vs Fuel Car',fuelType:'Other car fuel type',
petrol:'Petrol',diesel:'Diesel',hybrid:'Hybrid',
hybridNote:'A full (non-plug-in) hybrid is also measured in L/100km — it simply uses less (~4-5 L). For a PHEV, enter your average combined consumption.',
fuelPrice:'Fuel price ({s}/L)',fuelCons:'Consumption (L/100km)',calc:'Compare',
evCost:'EV per 100 {u} (net)',evCostG:'EV per 100 {u} (gross)',iceCost:'Fuel per 100 {u}',
discEffect:'Discount effect / 100 {u}',perUnitSaving:'Saving per {u}',
per100:'{v} saved per 100 {u}',savingByMonth:'Savings by month',
compareNote:'The chart shows savings vs driving the same recorded distance in a fuel car. Records with distance are used; savings use net paid amounts.',
needData:'Add charges with distance to calculate',
settingsTitle:'Settings',regionSection:'Country & Region',country:'Country',currency:'Currency',
unit:'Distance Unit',language:'Language',vehicles:'My Vehicles',addVehicle:'+ Add vehicle',
defaultHint:'★ default · km✎ odometer · 📷 photo · × archive',
formSection:'Charge Form',advAlways:'Advanced fields always open',
advAlwaysD:'Bank, duration, location and SoC range shown by default',
dataSection:'Data',exportJson:'Export (JSON)',exportCsv:'Export (CSV — Excel/Power BI)',
importJson:'Restore Backup (JSON)',reset:'Reset Data',about:'About',
aboutText:'WattTrack is completely free and ad-free. All your data stays on this device only; nothing is sent to any server, shared with third parties, or sold. No account needed. Only network use: exchange rates for foreign records (currency codes only) and location services when you tap 📍. Use the JSON backup to move data between devices.',
addTitle:'New Charge',editTitle:'Edit Charge',date:'Date',chargeType:'Charge Type',
company:'Home or Charging Company',homeChip:'Home',other:'Other…',kwh:'Energy (kWh)',
distance:'Distance driven ({u})',
freeCharge:'Free charge',freeChargeD:'Promo, home solar etc. — saved as 0',
amount:'Amount — before discount ({s})',discountType:'Discount Type',amountType:'Amount',percentType:'Percent (%)',
bank:'Bank',vehicle:'Vehicle',advanced:'+ Advanced',advancedHide:'− Hide advanced',
duration:'Charge time',hours:'hours',minutes:'minutes',location:'Location',
socRange:'SoC range % (start → end)',note:'Note',
rateLbl:'Rate (1 {f} = ? {b})',
rateNote:'Foreign spend is converted to {b} at the entered rate for statistics. Enter manually if not found.',
rateAuto:'Rate fetched automatically ({d})',rateNeeded:'Rate required for a foreign record',
gpsFail:'Could not get location — check permission',
formError:'Company, kWh and amount are required',save:'Save',
deleteAsk:'Delete this record?',deleted:'Record deleted',saved:'Charge saved',updated:'Charge updated',
obWelcome:'Welcome!',obCountryQ:'Where do you charge? We will set currency and distance unit accordingly.',
obCarQ:'Pick your car',obCarSub:'Type a brand or model — tell versions apart by year, trim and battery.',
searchCar:'e.g. Model Y, ID.4, Torres…',continue:'Continue',skip:'Skip',start:'Start',
battery:'Battery',arch:'Architecture',dcMax:'Max DC',acMax:'AC',range:'Range (WLTP)',
addPhoto:'📷 Add photo',changePhoto:'📷 Replace photo',
customAdd:'Add "{q}" as custom vehicle',vehicleAdded:'Vehicle added',photoAdded:'Photo added',add:'Add',
wipeAsk1:'ALL records, vehicles and settings will be deleted. Sure?',wipeAsk2:'Cannot be undone. Delete?',
wiped:'All data deleted',imported:'Backup restored',
importFail:'Not a valid WattTrack backup',importAsk:'records will be imported. Merge?',
jsonDone:'JSON backup downloaded',csvDone:'CSV downloaded',noData:'No records yet',sessions:'sessions'},

de:{navStats:'Statistik',statsTitle:'Statistiken',ice1:'Verbrenner 1 {u}',unitCostTitle:'Kosten pro Einheit — EV und Verbrenner nebeneinander',tcoExpEv:'EV-Fixkosten (Mein Auto)',tcoExpIce:'Fixkosten Verbrenner (anteilig)',tco1kmIce:'Verbrenner 1 {u} (mit Kosten)',tcoExplain:'Die EV-Fixkosten sind die unter „Mein Auto" eingetragenen Posten (Steuer, Versicherung, Wartung). Beim Verbrenner werden die oben eingegebenen jährlichen Fixkosten anteilig auf den Zeitraum umgelegt — beide Autos werden über denselben Zeitraum verglichen.',totalCostAll:'Gesamtkosten (Laden + fix)',fixedExpTotal:'Fixkosten gesamt',expChart:'Fixkosten-Diagramm',prorateLbl:'Jährliche Kosten (Steuer, Versicherung) anteilig rechnen',prorateNote:'Jährliche Posten zu {p}% angerechnet; tatsächlich gezahlt {r}.',exp_tax:'Steuer',exp_insurance:'Versicherung',exp_maintenance:'Wartung / Service',exp_tire:'Reifen',exp_inspection:'Hauptuntersuchung',exp_repair:'Reparatur / Schaden',exp_parking:'Parken / Maut',exp_equipment:'Ausstattung (Wallbox usw.)',exp_other:'Sonstiges',otherTypePh:'Titel eingeben — z.B. Zubehör, Autowäsche',addExpense:'Ausgabe hinzufügen',editExpense:'Ausgabe bearbeiten',expType:'Ausgabenart',expenses:'Fahrzeugkosten',expByCat:'Kosten nach Kategorie',expTotal:'Kosten gesamt',expAmount:'Betrag',noteLbl:'Notiz',amountNeeded:'Betrag eingeben',noExpenses:'Noch keine Kosten. Steuer, Versicherung und Wartung eintragen für die echten Kosten.',tcoTitle:'Gesamtkosten (Laden + Fixkosten)',tcoEv:'EV gesamt (Laden + Kosten)',tcoIce:'Verbrenner gesamt (mit Kosten)',tcoSaved:'Gesamtersparnis inkl. Kosten',tco1km:'EV pro 1 {u} (mit Kosten)',tcoNote:'Zeitraum {d} Tage. Fixkosten des Verbrenners anteilig: {f}.',nonFuelTitle:'Vergleich Nebenkosten (ohne Kraftstoff)',nonFuelKm:'Nebenkosten pro {u}',nonFuel100:'Nebenkosten pro 100 {u}',nonFuelYear:'Jährliche Nebenkosten',nonFuelKwh:'Nebenkosten pro kWh',nonFuelDiffYear:'Jährliche Nebenkosten-Differenz',nonFuelChart:'Jährliche Nebenkosten (EV / Verbrenner)',iceShort:'Verbrenner',chargePower:'Ø Ladeleistung',yearlyCompare:'Jahresvergleich',yearlySpendLbl:'Gesamtausgaben (dieses Jahr)',yearlyKwhLbl:'Energie (dieses Jahr)',yearlyPriceLbl:'Preis pro kWh (dieses Jahr)',weekdayDist:'Nach Wochentag',vsLastYear:'ggü. Vorjahr',iceFixHint:'Optional. Jährliche Steuer, Versicherung und Wartung eines vergleichbaren Verbrenners eintragen.',ev1:'EV pro 1 {u} ({x})',supportNote:'Diese App ist völlig kostenlos und werbefrei. Wenn Sie das Projekt unterstützen möchten, besuchen Sie gern unsere GitHub-Seite.',version:'Version',contactDev:'Fragen & Beiträge',privacy:'Datenschutz',rateApp:'Im Play Store bewerten',supportDev:'GitHub-Projektseite',kwhHint:'Links Ganzzahl, rechts 2 Dezimalstellen — 45 , 27 = 45,27 kWh. Nur Ziffern.',distFromOdo:'Distanzquelle: Kilometerstand (Fahrzeugdaten)',distFromRecords:'Distanzquelle: Distanzen der Einträge',back:'← Zurück',changeCar:'Fahrzeug ändern',navVehicle:'Mein Auto',vehicleTitle:'Mein Auto',odoAsk:'Aktueller Kilometerstand',odometer:'Kilometerstand',odoNow:'Tachostand',odoTracked:'Seit Beginn gefahren',odoPrompt:'Aktueller Stand ({u}):',odoStartPrompt:'Anfangs-/Kaufstand ({u}):',odoSaved:'Kilometerstand aktualisiert',theme:'Darstellung',themeLight:'Hell',themeDark:'Dunkel',spendChart:'Ausgabendiagramm',cumTitle:'Bisher: gleiche km mit Verbrenner',totalDist:'Gesamtstrecke',evSpent:'EV gesamt (netto)',iceWould:'Verbrenner-Kosten',totalSaved:'Gesamt gespart',evLine:'EV (real)',iceLine:'Verbrenner (gleiche km)',archived:'Archiv (verkauft/ungenutzt)',archivedTag:'archiviert — Einträge bleiben',archivedToast:'Fahrzeug archiviert, Einträge bleiben erhalten',restore:'Wiederherstellen',newBank:'+ Neue Bank…',newBankPrompt:'Bankname:',importAllDup:'Alle Einträge existieren bereits — nichts hinzugefügt.',importPartial:'{n} neue Einträge, {d} Duplikate übersprungen',netPaid:'Bezahlt (netto)',typeSplit:'Ladetyp-Verteilung (kWh)',detailStats:'Detail-Statistiken',avgDuration:'Ø Ladedauer',avgSocRange:'Ø Ladebereich',topBanks:'Banken (Rabattersparnis)',topLocations:'Häufigste Ladeorte',bankCountries:'Meine Bankländer',bankCountriesD:'Wähle die Länder deiner Karten — die Bankliste im Formular folgt diesen. Deine Banken ändern sich nicht mit dem Ladeland.',addCountry:'+ Land hinzufügen',prevPeriod:'ggü. Vorperiode',navHome:'Start',navHistory:'Verlauf',navCompare:'Vergleich',navSettings:'Einstellungen',
week:'Woche',month:'Monat',year:'Jahr',
periodWeek:'Diese Woche gesamt',periodMonth:'Dieser Monat gesamt',periodYear:'Dieses Jahr gesamt',
savings:'gespart',avgPerKwh:'Pro kWh',netLbl:'netto',grossLbl:'ohne Rabatt',
grossTotal:'Summe ohne Rabatte',cost100:'Pro 100 {u}',
totalKwhP:'Energie (kWh)',sessionsCompanies:'Ladungen / Anbieter',totalDiscP:'Erhaltene Rabatte',
freeCount:'Gratis-Ladungen',weeklySpend:'Wochenausgaben',monthlyTotals:'Monatsausgaben',
firmDist:'Nach Anbieter',recentCharges:'Letzte Ladungen',viewAll:'Alle',allVehicles:'Alle Fahrzeuge',
historyTitle:'Verlauf',allYears:'Alle Jahre',allFirms:'Alle Anbieter',allTypes:'Alle Typen',free:'Gratis',
compareTitle:'Vergleich mit Verbrenner',fuelType:'Kraftstoff des anderen Autos',
petrol:'Benzin',diesel:'Diesel',hybrid:'Hybrid',
hybridNote:'Auch ein Vollhybrid wird in L/100km gemessen — er verbraucht nur weniger (~4-5 L). Für PHEV den kombinierten Durchschnitt eingeben.',
fuelPrice:'Kraftstoffpreis ({s}/L)',fuelCons:'Verbrauch (L/100km)',calc:'Vergleichen',
evCost:'EV pro 100 {u} (netto)',evCostG:'EV pro 100 {u} (brutto)',iceCost:'Verbrenner 100 {u}',
discEffect:'Rabatteffekt / 100 {u}',perUnitSaving:'Ersparnis pro {u}',
per100:'{v} pro 100 {u} gespart',savingByMonth:'Ersparnis nach Monat',
compareNote:'Das Diagramm zeigt die Ersparnis gegenüber derselben Strecke mit einem Verbrenner. Einträge mit Distanz werden verwendet; netto berechnet.',
needData:'Ladungen mit Distanz erforderlich',
settingsTitle:'Einstellungen',regionSection:'Land & Region',country:'Land',currency:'Währung',
unit:'Entfernungseinheit',language:'Sprache',vehicles:'Meine Fahrzeuge',addVehicle:'+ Fahrzeug',
defaultHint:'★ Standard · km✎ Kilometerstand · 📷 Foto · × Archiv',
formSection:'Ladeformular',advAlways:'Erweiterte Felder immer offen',
advAlwaysD:'Bank, Dauer, Ort und Ladebereich standardmäßig anzeigen',
dataSection:'Daten',exportJson:'Export (JSON)',exportCsv:'Export (CSV — Excel/Power BI)',
importJson:'Backup wiederherstellen (JSON)',reset:'Daten zurücksetzen',about:'Info',
aboutText:'WattTrack — alle Daten bleiben auf diesem Gerät. Kostenlos, werbefrei; Daten werden nicht mit Dritten geteilt. Einzige Ausnahme: für Auslandseinträge wird der Wechselkurs online abgerufen (nur Währungscodes werden übertragen).',
addTitle:'Neue Ladung',editTitle:'Ladung bearbeiten',date:'Datum',chargeType:'Ladetyp',
company:'Zuhause oder Anbieter',homeChip:'Zuhause',other:'Andere…',kwh:'Energie (kWh)',
distance:'Gefahrene Strecke ({u})',
freeCharge:'Gratis-Ladung',freeChargeD:'Aktion, Solar usw. — als 0 gespeichert',
amount:'Betrag — vor Rabatt ({s})',discountType:'Rabattart',amountType:'Betrag',percentType:'Prozent (%)',
bank:'Bank',vehicle:'Fahrzeug',advanced:'+ Erweitert',advancedHide:'− Erweitert ausblenden',
duration:'Ladedauer',hours:'Std.',minutes:'Min.',location:'Ort',
socRange:'Ladebereich % (Start → Ende)',note:'Notiz',
rateLbl:'Kurs (1 {f} = ? {b})',
rateNote:'Auslandsausgaben werden zum eingegebenen Kurs in {b} umgerechnet. Bei Bedarf manuell eingeben.',
rateAuto:'Kurs automatisch geladen ({d})',rateNeeded:'Kurs für Auslandseintrag erforderlich',
gpsFail:'Standort nicht verfügbar — Berechtigung prüfen',
formError:'Anbieter, kWh und Betrag erforderlich',save:'Speichern',
deleteAsk:'Eintrag löschen?',deleted:'Eintrag gelöscht',saved:'Ladung gespeichert',updated:'Ladung aktualisiert',
obWelcome:'Willkommen!',obCountryQ:'Wo lädst du? Währung und Einheit werden entsprechend gesetzt.',
obCarQ:'Wähle dein Auto',obCarSub:'Marke oder Modell eingeben — Versionen nach Jahr und Akku unterscheiden.',
searchCar:'z.B. ID.4, EV6, Torres…',continue:'Weiter',skip:'Überspringen',start:'Los',
battery:'Akku',arch:'Architektur',dcMax:'Max DC',acMax:'AC',range:'Reichweite',
addPhoto:'📷 Foto hinzufügen',changePhoto:'📷 Foto ersetzen',
customAdd:'"{q}" als eigenes Fahrzeug',vehicleAdded:'Fahrzeug hinzugefügt',photoAdded:'Foto hinzugefügt',add:'Hinzufügen',
wipeAsk1:'ALLE Daten werden gelöscht. Sicher?',wipeAsk2:'Nicht rückgängig. Löschen?',
wiped:'Alle Daten gelöscht',imported:'Backup wiederhergestellt',
importFail:'Kein gültiges WattTrack-Backup',importAsk:'Einträge werden importiert. Zusammenführen?',
jsonDone:'JSON-Backup heruntergeladen',csvDone:'CSV heruntergeladen',noData:'Noch keine Einträge',sessions:'Ladungen'},

fr:{navStats:'Stats',statsTitle:'Statistiques',ice1:'Thermique 1 {u}',unitCostTitle:'Coût unitaire — VE et thermique côte à côte',tcoExpEv:'Frais fixes VE (Mon véhicule)',tcoExpIce:'Frais fixes thermique (au prorata)',tco1kmIce:'Thermique 1 {u} (avec dépenses)',tcoExplain:'Les frais fixes VE sont les postes (taxe, assurance, entretien) saisis dans Mon véhicule. Côté thermique, les frais fixes annuels saisis ci-dessus sont proratisés sur la période suivie — les deux voitures sont comparées sur la même période.',totalCostAll:'Coût total (recharge + fixes)',fixedExpTotal:'Total frais fixes',expChart:'Graphique des frais fixes',prorateLbl:'Proratiser les frais annuels (taxe, assurance) sur la période',prorateNote:'Postes annuels comptés à {p}% ; total réellement payé {r}.',exp_tax:'Taxe',exp_insurance:'Assurance',exp_maintenance:'Entretien / Révision',exp_tire:'Pneus',exp_inspection:'Contrôle technique',exp_repair:'Réparation',exp_parking:'Parking / Péage',exp_equipment:'Équipement (borne, etc.)',exp_other:'Autre',otherTypePh:'Saisir un titre — ex. Accessoires, Lavage',addExpense:'Ajouter une dépense',editExpense:'Modifier la dépense',expType:'Type de dépense',expenses:'Dépenses du véhicule',expByCat:'Dépenses par catégorie',expTotal:'Total des dépenses',expAmount:'Montant',noteLbl:'Note',amountNeeded:'Saisir un montant',noExpenses:'Aucune dépense. Ajoutez taxe, assurance et entretien pour voir le coût réel.',tcoTitle:'Coût total de possession (recharge + dépenses)',tcoEv:'VE total (recharge + dépenses)',tcoIce:'Thermique total (avec dépenses)',tcoSaved:'Économie totale avec dépenses',tco1km:'VE / 1 {u} (avec dépenses)',tcoNote:'Période suivie {d} jours. Coûts fixes du thermique au prorata : {f}.',nonFuelTitle:'Comparaison des frais hors carburant',nonFuelKm:'Frais hors carburant par {u}',nonFuel100:'Frais hors carburant par 100 {u}',nonFuelYear:'Frais hors carburant annuels',nonFuelKwh:'Frais hors carburant par kWh',nonFuelDiffYear:'Différence annuelle des frais hors carburant',nonFuelChart:'Frais hors carburant annuels (VE / Thermique)',iceShort:'Thermique',chargePower:'Puissance moy. de charge',yearlyCompare:'Comparaison annuelle',yearlySpendLbl:'Dépenses totales (cette année)',yearlyKwhLbl:'Énergie (cette année)',yearlyPriceLbl:'Prix au kWh (cette année)',weekdayDist:'Par jour de la semaine',vsLastYear:'vs année précédente',iceFixHint:'Facultatif. Indiquez le total annuel taxe, assurance et entretien d une voiture thermique comparable.',ev1:'VE / 1 {u} ({x})',supportNote:'Cette application est entièrement gratuite et sans publicité. Pour soutenir le projet, visitez notre page GitHub.',version:'Version',contactDev:'Questions et contributions',privacy:'Confidentialité',rateApp:'Noter sur le Play Store',supportDev:'Page GitHub du projet',kwhHint:'Gauche : entier, droite : 2 décimales — 45 , 27 = 45,27 kWh. Chiffres uniquement.',distFromOdo:'Source distance : compteur (infos véhicule)',distFromRecords:'Source distance : distances des charges',back:'← Retour',changeCar:'Changer de véhicule',navVehicle:'Mon véhicule',vehicleTitle:'Mon véhicule',odoAsk:'Kilométrage actuel',odometer:'Compteur',odoNow:'Compteur',odoTracked:'Parcourus depuis le début',odoPrompt:'Compteur actuel ({u}) :',odoStartPrompt:'Compteur initial ({u}) :',odoSaved:'Compteur mis à jour',theme:'Apparence',themeLight:'Clair',themeDark:'Sombre',spendChart:'Graphique des dépenses',cumTitle:'À ce jour : mêmes km en thermique',totalDist:'Distance totale',evSpent:'VE total (net)',iceWould:'Coût thermique',totalSaved:'Économie totale',evLine:'VE (réel)',iceLine:'Thermique (mêmes km)',archived:'Archive (vendu/inutilisé)',archivedTag:'archivé — charges conservées',archivedToast:'Véhicule archivé, ses charges sont conservées',restore:'Restaurer',newBank:'+ Nouvelle banque…',newBankPrompt:'Nom de la banque :',importAllDup:'Toutes les charges existent déjà — rien ajouté.',importPartial:'{n} nouvelles charges, {d} doublons ignorés',netPaid:'Payé (net)',typeSplit:'Répartition par type (kWh)',detailStats:'Statistiques détaillées',avgDuration:'Durée moy.',avgSocRange:'Plage moy.',topBanks:'Banques (gains remises)',topLocations:'Lieux les plus utilisés',bankCountries:'Mes pays bancaires',bankCountriesD:'Choisissez les pays de vos cartes — la liste des banques suit ces pays. Vos banques ne changent pas avec le pays de charge.',addCountry:'+ Ajouter un pays',prevPeriod:'vs période précédente',navHome:'Accueil',navHistory:'Historique',navCompare:'Comparer',navSettings:'Réglages',
week:'Semaine',month:'Mois',year:'Année',
periodWeek:'Total cette semaine',periodMonth:'Total ce mois',periodYear:'Total cette année',
savings:'économisé',avgPerKwh:'Par kWh',netLbl:'net',grossLbl:'sans remise',
grossTotal:'Total sans remises',cost100:'Par 100 {u}',
totalKwhP:'Énergie (kWh)',sessionsCompanies:'Charges / Réseaux',totalDiscP:'Remises reçues',
freeCount:'Charges gratuites',weeklySpend:'Dépenses hebdo',monthlyTotals:'Dépenses mensuelles',
firmDist:'Par réseau',recentCharges:'Charges récentes',viewAll:'Tout',allVehicles:'Tous véhicules',
historyTitle:'Historique',allYears:'Toutes années',allFirms:'Tous réseaux',allTypes:'Tous types',free:'Gratuit',
compareTitle:'Comparer vs Thermique',fuelType:'Carburant de l’autre voiture',
petrol:'Essence',diesel:'Diesel',hybrid:'Hybride',
hybridNote:'Une hybride non rechargeable se mesure aussi en L/100km — elle consomme simplement moins (~4-5 L). Pour une PHEV, saisissez la conso mixte moyenne.',
fuelPrice:'Prix carburant ({s}/L)',fuelCons:'Conso (L/100km)',calc:'Comparer',
evCost:'VE / 100 {u} (net)',evCostG:'VE / 100 {u} (brut)',iceCost:'Thermique 100 {u}',
discEffect:'Effet remises / 100 {u}',perUnitSaving:'Économie par {u}',
per100:'{v} économisés / 100 {u}',savingByMonth:'Économies par mois',
compareNote:'Le graphique montre l’économie vs la même distance en thermique. Charges avec distance utilisées ; calcul sur montants nets.',
needData:'Ajoutez des charges avec distance',
settingsTitle:'Réglages',regionSection:'Pays et région',country:'Pays',currency:'Devise',
unit:'Unité de distance',language:'Langue',vehicles:'Mes véhicules',addVehicle:'+ Véhicule',
defaultHint:'★ défaut · km✎ compteur · 📷 photo · × archive',
formSection:'Formulaire',advAlways:'Champs avancés toujours ouverts',
advAlwaysD:'Banque, durée, lieu et plage de charge affichés par défaut',
dataSection:'Données',exportJson:'Exporter (JSON)',exportCsv:'Exporter (CSV — Excel/Power BI)',
importJson:'Restaurer (JSON)',reset:'Réinitialiser',about:'À propos',
aboutText:'WattTrack — vos données restent sur cet appareil. Gratuit, sans publicité ; données non partagées avec des tiers. Seule exception : le taux de change est récupéré en ligne pour les charges à l’étranger (seuls les codes devises sont transmis).',
addTitle:'Nouvelle charge',editTitle:'Modifier la charge',date:'Date',chargeType:'Type de charge',
company:'Maison ou réseau',homeChip:'Maison',other:'Autre…',kwh:'Énergie (kWh)',
distance:'Distance parcourue ({u})',
freeCharge:'Charge gratuite',freeChargeD:'Promo, solaire… — enregistré à 0',
amount:'Montant — avant remise ({s})',discountType:'Type de remise',amountType:'Montant',percentType:'Pourcent (%)',
bank:'Banque',vehicle:'Véhicule',advanced:'+ Avancé',advancedHide:'− Masquer avancé',
duration:'Durée de charge',hours:'heures',minutes:'minutes',location:'Lieu',
socRange:'Plage de charge % (début → fin)',note:'Note',
rateLbl:'Taux (1 {f} = ? {b})',
rateNote:'Les dépenses à l’étranger sont converties en {b} au taux saisi. Saisir manuellement si introuvable.',
rateAuto:'Taux récupéré automatiquement ({d})',rateNeeded:'Taux requis pour une charge à l’étranger',
gpsFail:'Position indisponible — vérifiez l’autorisation',
formError:'Réseau, kWh et montant requis',save:'Enregistrer',
deleteAsk:'Supprimer cette charge ?',deleted:'Charge supprimée',saved:'Charge enregistrée',updated:'Charge modifiée',
obWelcome:'Bienvenue !',obCountryQ:'Où chargez-vous ? Devise et unité seront réglées en conséquence.',
obCarQ:'Choisissez votre voiture',obCarSub:'Tapez une marque ou un modèle — distinguez les versions par année et batterie.',
searchCar:'ex. Megane, ID.4, Torres…',continue:'Continuer',skip:'Passer',start:'Démarrer',
battery:'Batterie',arch:'Architecture',dcMax:'DC max',acMax:'AC',range:'Autonomie',
addPhoto:'📷 Ajouter une photo',changePhoto:'📷 Remplacer la photo',
customAdd:'Ajouter « {q} » en véhicule perso',vehicleAdded:'Véhicule ajouté',photoAdded:'Photo ajoutée',add:'Ajouter',
wipeAsk1:'TOUTES les données seront supprimées. Sûr ?',wipeAsk2:'Irréversible. Supprimer ?',
wiped:'Données supprimées',imported:'Sauvegarde restaurée',
importFail:'Sauvegarde WattTrack invalide',importAsk:'charges à importer. Fusionner ?',
jsonDone:'Sauvegarde JSON téléchargée',csvDone:'CSV téléchargé',noData:'Aucune charge',sessions:'charges'},

es:{navStats:'Datos',statsTitle:'Estadísticas',ice1:'Combustión 1 {u}',unitCostTitle:'Coste unitario — EV y combustión lado a lado',tcoExpEv:'Gastos fijos EV (Mi vehículo)',tcoExpIce:'Coste fijo combustión (prorrateado)',tco1kmIce:'Combustión 1 {u} (con gastos)',tcoExplain:'Los gastos fijos del EV son los conceptos (impuesto, seguro, mantenimiento) introducidos en Mi vehículo. En el lado de combustión, el coste fijo anual introducido arriba se prorratea al periodo seguido — ambos coches se comparan en el mismo periodo.',totalCostAll:'Coste total (carga + fijos)',fixedExpTotal:'Total gastos fijos',expChart:'Gráfico de gastos fijos',prorateLbl:'Prorratear gastos anuales (impuesto, seguro) al periodo',prorateNote:'Partidas anuales al {p}% del periodo; total realmente pagado {r}.',exp_tax:'Impuesto',exp_insurance:'Seguro',exp_maintenance:'Mantenimiento / Taller',exp_tire:'Neumáticos',exp_inspection:'ITV',exp_repair:'Reparación',exp_parking:'Aparcamiento / Peaje',exp_equipment:'Equipamiento (cargador, etc.)',exp_other:'Otros',otherTypePh:'Escribe un título — ej. Accesorios, Lavado',addExpense:'Añadir gasto',editExpense:'Editar gasto',expType:'Tipo de gasto',expenses:'Gastos del vehículo',expByCat:'Gastos por categoría',expTotal:'Gastos totales',expAmount:'Importe',noteLbl:'Nota',amountNeeded:'Introduce un importe',noExpenses:'Sin gastos aún. Añade impuesto, seguro y mantenimiento para ver el coste real.',tcoTitle:'Coste total de propiedad (carga + gastos)',tcoEv:'EV total (carga + gastos)',tcoIce:'Combustión total (con gastos)',tcoSaved:'Ahorro total con gastos',tco1km:'EV por 1 {u} (con gastos)',tcoNote:'Periodo seguido {d} días. Costes fijos del coche de combustión prorrateados: {f}.',nonFuelTitle:'Comparación de gastos sin combustible',nonFuelKm:'Gastos sin combustible por {u}',nonFuel100:'Gastos sin combustible por 100 {u}',nonFuelYear:'Gastos anuales sin combustible',nonFuelKwh:'Gastos sin combustible por kWh',nonFuelDiffYear:'Diferencia anual de gastos sin combustible',nonFuelChart:'Gastos anuales sin combustible (EV / Combustión)',iceShort:'Combustión',chargePower:'Potencia media de carga',yearlyCompare:'Comparación anual',yearlySpendLbl:'Gasto total (este año)',yearlyKwhLbl:'Energía (este año)',yearlyPriceLbl:'Precio por kWh (este año)',weekdayDist:'Por día de la semana',vsLastYear:'vs año anterior',iceFixHint:'Opcional. Indica el total anual de impuesto, seguro y mantenimiento de un coche de combustión similar.',ev1:'EV por 1 {u} ({x})',supportNote:'Esta aplicación es totalmente gratuita y sin anuncios. Para apoyar el proyecto, visita nuestra página de GitHub.',version:'Versión',contactDev:'Preguntas y aportes',privacy:'Privacidad',rateApp:'Valorar en Play Store',supportDev:'Página del proyecto en GitHub',kwhHint:'Izquierda entero, derecha 2 decimales — 45 , 27 = 45,27 kWh. Solo dígitos.',distFromOdo:'Fuente de distancia: cuentakilómetros',distFromRecords:'Fuente de distancia: distancias por carga',back:'← Atrás',changeCar:'Cambiar vehículo',navVehicle:'Mi vehículo',vehicleTitle:'Mi vehículo',odoAsk:'Kilometraje actual',odometer:'Cuentakilómetros',odoNow:'Cuentakilómetros',odoTracked:'Recorridos desde el inicio',odoPrompt:'Lectura actual ({u}):',odoStartPrompt:'Lectura inicial ({u}):',odoSaved:'Kilometraje actualizado',theme:'Apariencia',themeLight:'Claro',themeDark:'Oscuro',spendChart:'Gráfico de gasto',cumTitle:'Hasta hoy: mismos km con combustión',totalDist:'Distancia total',evSpent:'EV total (neto)',iceWould:'Costaría (combustión)',totalSaved:'Ahorro total',evLine:'EV (real)',iceLine:'Combustión (mismos km)',archived:'Archivo (vendido/sin uso)',archivedTag:'archivado — cargas conservadas',archivedToast:'Vehículo archivado, sus cargas se conservan',restore:'Restaurar',newBank:'+ Añadir banco…',newBankPrompt:'Nombre del banco:',importAllDup:'Todas las cargas ya existen — no se añadió nada.',importPartial:'{n} cargas nuevas, {d} duplicadas omitidas',netPaid:'Pagado (neto)',typeSplit:'Reparto por tipo (kWh)',detailStats:'Estadísticas detalladas',avgDuration:'Duración media',avgSocRange:'Rango medio',topBanks:'Bancos (ahorro por dtos.)',topLocations:'Lugares más usados',bankCountries:'Mis países bancarios',bankCountriesD:'Elige los países de tus tarjetas — la lista de bancos del formulario los sigue. Tus bancos no cambian con el país de carga.',addCountry:'+ Añadir país',prevPeriod:'vs periodo anterior',navHome:'Inicio',navHistory:'Historial',navCompare:'Comparar',navSettings:'Ajustes',
week:'Semana',month:'Mes',year:'Año',
periodWeek:'Total esta semana',periodMonth:'Total este mes',periodYear:'Total este año',
savings:'ahorrado',avgPerKwh:'Por kWh',netLbl:'neto',grossLbl:'sin dto.',
grossTotal:'Total sin descuentos',cost100:'Por 100 {u}',
totalKwhP:'Energía (kWh)',sessionsCompanies:'Cargas / Redes',totalDiscP:'Descuentos recibidos',
freeCount:'Cargas gratis',weeklySpend:'Gasto semanal',monthlyTotals:'Gasto mensual',
firmDist:'Por red',recentCharges:'Cargas recientes',viewAll:'Todo',allVehicles:'Todos los vehículos',
historyTitle:'Historial',allYears:'Todos los años',allFirms:'Todas las redes',allTypes:'Todos los tipos',free:'Gratis',
compareTitle:'Comparar vs Combustión',fuelType:'Combustible del otro coche',
petrol:'Gasolina',diesel:'Diésel',hybrid:'Híbrido',
hybridNote:'Un híbrido no enchufable también se mide en L/100km — solo consume menos (~4-5 L). Para un PHEV, introduce el consumo combinado medio.',
fuelPrice:'Precio ({s}/L)',fuelCons:'Consumo (L/100km)',calc:'Comparar',
evCost:'EV / 100 {u} (neto)',evCostG:'EV / 100 {u} (bruto)',iceCost:'Combustión 100 {u}',
discEffect:'Efecto descuentos / 100 {u}',perUnitSaving:'Ahorro por {u}',
per100:'{v} ahorrados / 100 {u}',savingByMonth:'Ahorro por mes',
compareNote:'El gráfico muestra el ahorro frente a la misma distancia con combustión. Se usan cargas con distancia; cálculo sobre importes netos.',
needData:'Añade cargas con distancia',
settingsTitle:'Ajustes',regionSection:'País y región',country:'País',currency:'Moneda',
unit:'Unidad de distancia',language:'Idioma',vehicles:'Mis vehículos',addVehicle:'+ Vehículo',
defaultHint:'★ predeterminado · km✎ kilometraje · 📷 foto · × archivo',
formSection:'Formulario',advAlways:'Campos avanzados siempre abiertos',
advAlwaysD:'Banco, duración, lugar y rango visibles por defecto',
dataSection:'Datos',exportJson:'Exportar (JSON)',exportCsv:'Exportar (CSV — Excel/Power BI)',
importJson:'Restaurar copia (JSON)',reset:'Restablecer datos',about:'Acerca de',
aboutText:'WattTrack — tus datos permanecen en este dispositivo. Gratis, sin anuncios; datos no compartidos con terceros. Única excepción: el tipo de cambio se obtiene online para cargas en el extranjero (solo se transmiten códigos de moneda).',
addTitle:'Nueva carga',editTitle:'Editar carga',date:'Fecha',chargeType:'Tipo de carga',
company:'Casa o red de carga',homeChip:'Casa',other:'Otra…',kwh:'Energía (kWh)',
distance:'Distancia recorrida ({u})',
freeCharge:'Carga gratis',freeChargeD:'Promo, solar… — se guarda como 0',
amount:'Importe — antes de dto. ({s})',discountType:'Tipo de descuento',amountType:'Importe',percentType:'Porcentaje (%)',
bank:'Banco',vehicle:'Vehículo',advanced:'+ Avanzado',advancedHide:'− Ocultar avanzado',
duration:'Duración',hours:'horas',minutes:'minutos',location:'Lugar',
socRange:'Rango de carga % (inicio → fin)',note:'Nota',
rateLbl:'Tipo (1 {f} = ? {b})',
rateNote:'El gasto en el extranjero se convierte a {b} al tipo introducido. Introduce manualmente si no se encuentra.',
rateAuto:'Tipo obtenido automáticamente ({d})',rateNeeded:'Tipo requerido para carga en el extranjero',
gpsFail:'Ubicación no disponible — comprueba el permiso',
formError:'Red, kWh e importe requeridos',save:'Guardar',
deleteAsk:'¿Eliminar esta carga?',deleted:'Carga eliminada',saved:'Carga guardada',updated:'Carga actualizada',
obWelcome:'¡Bienvenido!',obCountryQ:'¿Dónde cargas? Ajustaremos moneda y unidad.',
obCarQ:'Elige tu coche',obCarSub:'Escribe marca o modelo — distingue versiones por año y batería.',
searchCar:'ej. Model 3, EV6, Torres…',continue:'Continuar',skip:'Omitir',start:'Empezar',
battery:'Batería',arch:'Arquitectura',dcMax:'DC máx',acMax:'AC',range:'Autonomía',
addPhoto:'📷 Añadir foto',changePhoto:'📷 Cambiar foto',
customAdd:'Añadir «{q}» como vehículo propio',vehicleAdded:'Vehículo añadido',photoAdded:'Foto añadida',add:'Añadir',
wipeAsk1:'Se borrarán TODOS los datos. ¿Seguro?',wipeAsk2:'Irreversible. ¿Borrar?',
wiped:'Datos borrados',imported:'Copia restaurada',
importFail:'Copia WattTrack no válida',importAsk:'cargas se importarán. ¿Combinar?',
jsonDone:'Copia JSON descargada',csvDone:'CSV descargado',noData:'Sin cargas aún',sessions:'cargas'},

it:{navStats:'Statistiche',statsTitle:'Statistiche',ice1:'Termica 1 {u}',unitCostTitle:'Costo unitario — EV e termica affiancate',tcoExpEv:'Costi fissi EV (Il mio veicolo)',tcoExpIce:'Costi fissi termica (in proporzione)',tco1kmIce:'Termica 1 {u} (con spese)',tcoExplain:'I costi fissi EV sono le voci (bollo, assicurazione, manutenzione) inserite ne Il mio veicolo. Sul lato termica, il costo fisso annuo inserito sopra è ripartito sul periodo monitorato — le due auto sono confrontate sullo stesso periodo.',totalCostAll:'Costo totale (ricarica + fissi)',fixedExpTotal:'Totale costi fissi',expChart:'Grafico costi fissi',prorateLbl:'Ripartisci le spese annuali (bollo, assicurazione) sul periodo',prorateNote:'Voci annuali al {p}% del periodo; totale realmente pagato {r}.',exp_tax:'Bollo',exp_insurance:'Assicurazione',exp_maintenance:'Manutenzione / Tagliando',exp_tire:'Pneumatici',exp_inspection:'Revisione',exp_repair:'Riparazione',exp_parking:'Parcheggio / Pedaggi',exp_equipment:'Attrezzatura (wallbox ecc.)',exp_other:'Altro',otherTypePh:'Scrivi un titolo — es. Accessori, Lavaggio',addExpense:'Aggiungi spesa',editExpense:'Modifica spesa',expType:'Tipo di spesa',expenses:'Spese del veicolo',expByCat:'Spese per categoria',expTotal:'Spese totali',expAmount:'Importo',noteLbl:'Nota',amountNeeded:'Inserisci un importo',noExpenses:'Nessuna spesa. Aggiungi bollo, assicurazione e manutenzione per il costo reale.',tcoTitle:'Costo totale di possesso (ricarica + spese)',tcoEv:'EV totale (ricarica + spese)',tcoIce:'Termica totale (con spese)',tcoSaved:'Risparmio totale con spese',tco1km:'EV per 1 {u} (con spese)',tcoNote:'Periodo monitorato {d} giorni. Costi fissi della termica in proporzione: {f}.',nonFuelTitle:'Confronto spese non di carburante',nonFuelKm:'Spese non di carburante per {u}',nonFuel100:'Spese non di carburante per 100 {u}',nonFuelYear:'Spese annue non di carburante',nonFuelKwh:'Spese non di carburante per kWh',nonFuelDiffYear:'Differenza annua spese non di carburante',nonFuelChart:'Spese annue non di carburante (EV / Termica)',iceShort:'Termica',chargePower:'Potenza media di ricarica',yearlyCompare:'Confronto annuale',yearlySpendLbl:'Spesa totale (quest’anno)',yearlyKwhLbl:'Energia (quest’anno)',yearlyPriceLbl:'Prezzo per kWh (quest’anno)',weekdayDist:'Per giorno della settimana',vsLastYear:'vs anno precedente',iceFixHint:'Facoltativo. Inserisci il totale annuo di bollo, assicurazione e manutenzione di una termica simile.',ev1:'EV per 1 {u} ({x})',supportNote:'Questa app è completamente gratuita e senza pubblicità. Per sostenere il progetto, visita la nostra pagina GitHub.',version:'Versione',contactDev:'Domande e contributi',privacy:'Privacy',rateApp:'Valuta su Play Store',supportDev:'Pagina GitHub del progetto',kwhHint:'Sinistra intero, destra 2 decimali — 45 , 27 = 45,27 kWh. Solo cifre.',distFromOdo:'Fonte distanza: contachilometri',distFromRecords:'Fonte distanza: distanze delle ricariche',back:'← Indietro',changeCar:'Cambia veicolo',navVehicle:'Il mio veicolo',vehicleTitle:'Il mio veicolo',odoAsk:'Chilometraggio attuale',odometer:'Contachilometri',odoNow:'Contachilometri',odoTracked:'Percorsi dall’inizio',odoPrompt:'Lettura attuale ({u}):',odoStartPrompt:'Lettura iniziale ({u}):',odoSaved:'Contachilometri aggiornato',theme:'Aspetto',themeLight:'Chiaro',themeDark:'Scuro',spendChart:'Grafico spese',cumTitle:'Finora: stessi km con termica',totalDist:'Distanza totale',evSpent:'EV totale (netto)',iceWould:'Costerebbe (termica)',totalSaved:'Risparmio totale',evLine:'EV (reale)',iceLine:'Termica (stessi km)',archived:'Archivio (venduto/inutilizzato)',archivedTag:'archiviato — ricariche conservate',archivedToast:'Veicolo archiviato, le ricariche restano',restore:'Ripristina',newBank:'+ Nuova banca…',newBankPrompt:'Nome banca:',importAllDup:'Tutte le ricariche esistono già — nulla aggiunto.',importPartial:'{n} nuove ricariche, {d} duplicati saltati',netPaid:'Pagato (netto)',typeSplit:'Ripartizione per tipo (kWh)',detailStats:'Statistiche dettagliate',avgDuration:'Durata media',avgSocRange:'Intervallo medio',topBanks:'Banche (risparmio sconti)',topLocations:'Luoghi più usati',bankCountries:'I miei paesi bancari',bankCountriesD:'Scegli i paesi delle tue carte — l’elenco banche nel modulo li segue. Le tue banche non cambiano col paese di ricarica.',addCountry:'+ Aggiungi paese',prevPeriod:'vs periodo precedente',navHome:'Home',navHistory:'Cronologia',navCompare:'Confronta',navSettings:'Impostazioni',
week:'Settimana',month:'Mese',year:'Anno',
periodWeek:'Totale settimana',periodMonth:'Totale mese',periodYear:'Totale anno',
savings:'risparmiato',avgPerKwh:'Per kWh',netLbl:'netto',grossLbl:'senza sconto',
grossTotal:'Totale senza sconti',cost100:'Per 100 {u}',
totalKwhP:'Energia (kWh)',sessionsCompanies:'Ricariche / Reti',totalDiscP:'Sconti ricevuti',
freeCount:'Ricariche gratis',weeklySpend:'Spesa settimanale',monthlyTotals:'Spesa mensile',
firmDist:'Per rete',recentCharges:'Ricariche recenti',viewAll:'Tutte',allVehicles:'Tutti i veicoli',
historyTitle:'Cronologia',allYears:'Tutti gli anni',allFirms:'Tutte le reti',allTypes:'Tutti i tipi',free:'Gratis',
compareTitle:'Confronta vs Termica',fuelType:'Carburante dell’altra auto',
petrol:'Benzina',diesel:'Diesel',hybrid:'Ibrida',
hybridNote:'Anche un’ibrida non ricaricabile si misura in L/100km — consuma solo meno (~4-5 L). Per una PHEV inserisci il consumo combinato medio.',
fuelPrice:'Prezzo ({s}/L)',fuelCons:'Consumo (L/100km)',calc:'Confronta',
evCost:'EV / 100 {u} (netto)',evCostG:'EV / 100 {u} (lordo)',iceCost:'Termica 100 {u}',
discEffect:'Effetto sconti / 100 {u}',perUnitSaving:'Risparmio per {u}',
per100:'{v} risparmiati / 100 {u}',savingByMonth:'Risparmio per mese',
compareNote:'Il grafico mostra il risparmio rispetto alla stessa distanza con un’auto termica. Ricariche con distanza; calcolo su importi netti.',
needData:'Aggiungi ricariche con distanza',
settingsTitle:'Impostazioni',regionSection:'Paese e regione',country:'Paese',currency:'Valuta',
unit:'Unità di distanza',language:'Lingua',vehicles:'I miei veicoli',addVehicle:'+ Veicolo',
defaultHint:'★ predefinito · km✎ contachilometri · 📷 foto · × archivio',
formSection:'Modulo',advAlways:'Campi avanzati sempre aperti',
advAlwaysD:'Banca, durata, luogo e intervallo visibili di default',
dataSection:'Dati',exportJson:'Esporta (JSON)',exportCsv:'Esporta (CSV — Excel/Power BI)',
importJson:'Ripristina backup (JSON)',reset:'Azzera dati',about:'Info',
aboutText:'WattTrack — i tuoi dati restano su questo dispositivo. Gratuita, senza pubblicità; dati non condivisi con terzi. Unica eccezione: il tasso di cambio è recuperato online per ricariche all’estero (si trasmettono solo i codici valuta).',
addTitle:'Nuova ricarica',editTitle:'Modifica ricarica',date:'Data',chargeType:'Tipo di ricarica',
company:'Casa o rete di ricarica',homeChip:'Casa',other:'Altra…',kwh:'Energia (kWh)',
distance:'Distanza percorsa ({u})',
freeCharge:'Ricarica gratis',freeChargeD:'Promo, solare… — salvata come 0',
amount:'Importo — prima dello sconto ({s})',discountType:'Tipo di sconto',amountType:'Importo',percentType:'Percento (%)',
bank:'Banca',vehicle:'Veicolo',advanced:'+ Avanzate',advancedHide:'− Nascondi avanzate',
duration:'Durata',hours:'ore',minutes:'minuti',location:'Luogo',
socRange:'Intervallo carica % (inizio → fine)',note:'Nota',
rateLbl:'Tasso (1 {f} = ? {b})',
rateNote:'La spesa all’estero è convertita in {b} al tasso inserito. Inserisci manualmente se non trovato.',
rateAuto:'Tasso recuperato automaticamente ({d})',rateNeeded:'Tasso richiesto per ricarica all’estero',
gpsFail:'Posizione non disponibile — controlla i permessi',
formError:'Rete, kWh e importo obbligatori',save:'Salva',
deleteAsk:'Eliminare questa ricarica?',deleted:'Ricarica eliminata',saved:'Ricarica salvata',updated:'Ricarica aggiornata',
obWelcome:'Benvenuto!',obCountryQ:'Dove ricarichi? Imposteremo valuta e unità di conseguenza.',
obCarQ:'Scegli la tua auto',obCarSub:'Scrivi marca o modello — distingui le versioni per anno e batteria.',
searchCar:'es. 500e, Model 3, Torres…',continue:'Continua',skip:'Salta',start:'Inizia',
battery:'Batteria',arch:'Architettura',dcMax:'DC max',acMax:'AC',range:'Autonomia',
addPhoto:'📷 Aggiungi foto',changePhoto:'📷 Sostituisci foto',
customAdd:'Aggiungi «{q}» come veicolo personale',vehicleAdded:'Veicolo aggiunto',photoAdded:'Foto aggiunta',add:'Aggiungi',
wipeAsk1:'TUTTI i dati saranno eliminati. Sicuro?',wipeAsk2:'Irreversibile. Eliminare?',
wiped:'Dati eliminati',imported:'Backup ripristinato',
importFail:'Backup WattTrack non valido',importAsk:'ricariche da importare. Unire?',
jsonDone:'Backup JSON scaricato',csvDone:'CSV scaricato',noData:'Nessuna ricarica',sessions:'ricariche'}
};
const LANG_NAMES = {tr:'Türkçe',en:'English',de:'Deutsch',fr:'Français',es:'Español',it:'Italiano'};
const MONTHS = {
tr:['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'],
en:['January','February','March','April','May','June','July','August','September','October','November','December'],
de:['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
fr:['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'],
es:['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
it:['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre']
};
const DAYS = {
tr:['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'], en:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
de:['Mo','Di','Mi','Do','Fr','Sa','So'], fr:['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'],
es:['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'], it:['Lun','Mar','Mer','Gio','Ven','Sab','Dom']
};

// ---------- Durum & yardımcılar ----------
const S = {
  country: 'TR', currency: 'TRY', unit: 'km', lang: 'tr',
  advOpen: false, defaultVehicleId: null, onboarded: false,
  period: 'year', cmp: null, dashVeh: '', cmpVeh: '', vehExpVeh: '', vehExpGran: 'month', bankCountries: null, gran: 'month', customBanks: [], theme: 'light', dstatType: ''
};
const $ = id => document.getElementById(id);
const t = (key, vars) => {
  let s = (T[S.lang] && T[S.lang][key]) ?? T.en[key] ?? key;
  if (vars) for (const k in vars) s = s.split('{' + k + '}').join(vars[k]);
  return s;
};
// virgül toleranslı sayı okuma ("45,5" → 45.5)
const pf = v => {
  const n = parseFloat(String(v ?? '').trim().replace(',', '.'));
  return isNaN(n) ? NaN : n;
};
const symOf = code => CURRENCY_SYMBOLS[code] || code;
const sym = () => symOf(S.currency);
// Harf içeren semboller (L, kr, Kč, Ft…) sayının SONUNA boşlukla gelir: "1.250 L";
// işaret semboller (₺ € $ £) başa gelir: "₺1.250"
const fm = (s, str) => /^[A-Za-z]/.test(s) ? str + ' ' + s : s + str;
const money = v => (v < 0 ? '−' : '') + fm(sym(), Math.abs(Math.round(v || 0)).toLocaleString('tr-TR'));
const money2 = v => (v < 0 ? '−' : '') + fm(sym(), Math.abs(v || 0).toLocaleString('tr-TR', {maximumFractionDigits: 2}));
const monthKey = iso => iso.slice(0, 7);
const distDisp = km => S.unit === 'mi' ? km / MI : km;
const distFactor = () => S.unit === 'mi' ? MI : 1;   // 100 birim = 100*factor km

// Açılış animasyonu: gerçek yükleme paralelde sürer, splash yalnız görsel bir katman —
// en az SPLASH_MIN_MS gösterilir ki animasyon yarıda kesilmiş gibi durmasın.
// (popüler mobil uygulamalardaki ~2 sn marka splash süresi baz alındı)
const SPLASH_MIN_MS = 2000;
const splashStart = Date.now();
function hideSplash() {
  const el = document.getElementById('splash');
  if (!el) return;
  const wait = Math.max(0, SPLASH_MIN_MS - (Date.now() - splashStart));
  setTimeout(() => {
    el.classList.add('hide');
    setTimeout(() => el.remove(), 600);
  }, wait);
}
function toast(msg) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._h);
  el._h = setTimeout(() => el.classList.remove('show'), 2400);
}
function esc(s) {
  return (s || '').toString().replace(/[&<>"']/g,
    c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function colorFor(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h += name.charCodeAt(i);
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
// indirim (tasarruf) — kayıt para biriminde
// v6+: kayıtta hazır `indirim` alanı var (brüt − net). Eski kayıtlar için formül.
function savingsOf(r) {
  if (r.free) return 0;
  if (r.indirim != null) return Number(r.indirim) || 0;
  if (r.indirimTip === 'percent') {
    const v = Number(r.indirimDeger) || 0;
    return v >= 100 ? 0 : r.odenen * v / (100 - v);
  }
  if (r.indirimTip === 'amount') return Number(r.indirimDeger) || 0;
  return 0;
}
// brütten neti hesapla (form ve kayıt için tek doğruluk kaynağı)
function netFromGross(gross, type, val) {
  const v = Number(val) || 0;
  if (v <= 0) return gross;
  const net = type === 'percent' ? gross * (1 - Math.min(100, v) / 100) : gross - v;
  return Math.max(0, net);
}
// ---- ÇİFT YÖNLÜ KUR: kayıt kendi para birimini korur ----
// Dönüşüm katsayısı; çevrilemiyorsa null (toplam dışı bırakılır)
let fxPendingCount = 0;
function convOf(r) {
  const c = r.cur || S.currency;
  if (c === S.currency) return 1;
  if (r.fxTable && r.fxTable[S.currency]) return r.fxTable[S.currency];
  if (r.rate && (r.rateBase === S.currency || !r.rateBase)) return Number(r.rate);
  return null;
}
const amtB = r => { const k = convOf(r); return k == null ? 0 : (r.odenen || 0) * k; };
const savB = r => { const k = convOf(r); return k == null ? 0 : savingsOf(r) * k; };
const isConv = r => convOf(r) != null;
const expB = e => { const k = convOf(e); return k == null ? 0 : (e.tutar || 0) * k; };
function shortDate(iso) {
  const [, m, d] = iso.slice(0, 10).split('-').map(Number);
  return d + ' ' + MONTHS[S.lang][m - 1].slice(0, 3);
}
async function saveSetting(key, value) { await db.settings.put({key, value}); }
// Kayıt eklenince/değişince/silinince aracın sayacına mesafe farkını işle.
// Yalnız formdan yapılan işlemlerde çalışır (içe aktarma sayaca DOKUNMAZ —
// yedekteki sayaç değeri zaten o kayıtları içerir, çift sayım olmasın).
async function bumpVehicleKm(aracId, deltaKm) {
  if (!deltaKm) return;
  const vs = (await db.vehicles.toArray()).filter(v => !v.archived);
  const v = (aracId && vs.find(x => x.id === aracId)) || pickOdoVeh(vs, '');
  if (!v || v.kmNow == null) return;   // sayaç kullanılmıyorsa karışma
  const yeni = Math.max(v.kmStart ?? 0, Math.round(v.kmNow + deltaKm));
  await db.vehicles.update(v.id, {kmNow: yeni});
}
function applyTheme() {
  const dark = S.theme === 'dark';
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const mt = document.querySelector('meta[name="theme-color"]');
  if (mt) mt.content = dark ? '#0f172a' : '#F1F7F2';
  document.querySelectorAll('[data-themetoggle]').forEach(b => { b.textContent = dark ? '☀️' : '🌙'; });
  const st = document.getElementById('set-theme');
  if (st) st.querySelectorAll('button').forEach(x =>
    x.classList.toggle('sel', x.dataset.v === (dark ? 'dark' : 'light')));
}
document.querySelectorAll('[data-themetoggle]').forEach(b =>
  b.addEventListener('click', async () => {
    S.theme = S.theme === 'dark' ? 'light' : 'dark';
    await saveSetting('theme', S.theme);
    applyTheme();
    RENDER[screen]?.();   // grafik/donut renkleri temaya göre yeniden çizilsin
  }));
const chargersFor = code => (CHARGERS[code] || CHARGERS_DEFAULT);
const banksFor = code => (BANKS_BY[code] || BANKS_DEFAULT);
// Banka listesi: kullanıcının banka ülkelerinin birleşimi (şarj ülkesinden bağımsız)
function bankOptions() {
  const codes = (S.bankCountries && S.bankCountries.length) ? S.bankCountries : [S.country];
  const list = [...(S.customBanks || [])];
  codes.forEach(cc => banksFor(cc).forEach(b => { if (!list.includes(b)) list.push(b); }));
  ['Visa', 'Mastercard'].forEach(b => { if (!list.includes(b)) list.push(b); });
  return ['', ...list].map(b => `<option value="${esc(b)}">${b || '—'}</option>`).join('') +
    `<option value="__newbank">${t('newBank')}</option>`;
}

// ---------- araç silüetleri & özet kartı ----------
function carSVG(body, color) {
  const c = color || '#1C8742';
  const P = {
    sedan: 'M20 62 Q22 50 42 47 L62 34 Q80 26 112 26 Q144 26 158 36 L170 46 Q196 49 202 58 Q206 62 204 68 L188 68 A14 14 0 0 0 160 68 L84 68 A14 14 0 0 0 56 68 L24 68 Q18 66 20 62 Z',
    suv:   'M20 60 Q20 44 40 42 L56 26 Q64 18 100 18 Q140 18 152 28 L166 42 Q198 45 202 56 Q205 62 202 68 L186 68 A14 14 0 0 0 158 68 L82 68 A14 14 0 0 0 54 68 L24 68 Q17 66 20 60 Z',
    hatch: 'M24 60 Q24 46 44 44 L58 28 Q66 20 100 20 Q126 20 138 28 L154 44 Q182 47 188 56 Q192 62 188 68 L174 68 A13 13 0 0 0 148 68 L82 68 A13 13 0 0 0 56 68 L28 68 Q21 66 24 60 Z',
    pickup:'M18 62 Q18 46 38 44 L52 26 Q58 18 92 18 L108 18 L110 42 L196 42 Q204 44 204 56 L204 62 Q204 68 198 68 L184 68 A14 14 0 0 0 156 68 L82 68 A14 14 0 0 0 54 68 L22 68 Q16 66 18 62 Z',
    van:   'M20 62 Q20 30 44 28 L150 24 Q196 24 202 46 L202 60 Q202 68 196 68 L184 68 A14 14 0 0 0 156 68 L82 68 A14 14 0 0 0 54 68 L24 68 Q18 66 20 62 Z'
  };
  const win = {
    sedan: 'M66 36 L112 30 Q136 30 150 38 L118 44 L70 44 Z',
    suv:   'M60 28 L100 24 Q132 24 146 32 L118 42 L64 42 Z',
    hatch: 'M62 30 L100 26 Q120 26 132 32 L116 42 L66 42 Z',
    pickup:'M56 28 L92 24 L104 24 L106 40 L60 40 Z',
    van:   'M48 32 L140 28 Q170 28 182 40 L150 46 L52 46 Z'
  };
  return `<svg viewBox="0 0 220 84" xmlns="http://www.w3.org/2000/svg">
    <path d="${P[body] || P.suv}" fill="${c}" opacity=".9"/>
    <path d="${win[body] || win.suv}" fill="#F1F7F2" opacity=".85"/>
    <circle cx="70" cy="68" r="11" fill="#131714"/><circle cx="70" cy="68" r="5" fill="#8B918C"/>
    <circle cx="172" cy="68" r="11" fill="#131714"/><circle cx="172" cy="68" r="5" fill="#8B918C"/>
  </svg>`;
}
function evSummaryHTML(v) {
  const yr = v.y1 ? (v.y1 + (v.y2 ? '–' + v.y2 : '+')) : '—';
  const visual = v.photo
    ? `<img class="carphoto" src="${v.photo}" alt="">`
    : carSVG(v.body, colorFor(v.brand || v.ad || ''));
  return `<div class="ev-summary">
    ${visual}
    <div class="name">${esc((v.brand ? v.brand + ' ' : '') + (v.model || v.ad || ''))}</div>
    <div class="trim">${esc(v.trim || '')}${v.trim ? ' · ' : ''}${yr}</div>
    <div class="spec-grid">
      <div class="spec"><div class="k">${t('battery')}</div><div class="v">${v.batt ? v.batt + ' kWh' : '—'}</div></div>
      <div class="spec"><div class="k">${t('arch')}</div><div class="v">${v.arch ? v.arch + ' V' : '—'}</div></div>
      <div class="spec"><div class="k">${t('dcMax')}</div><div class="v">${v.dc ? v.dc + ' kW' : '—'}</div></div>
      <div class="spec"><div class="k">${t('acMax')}</div><div class="v">${v.ac ? v.ac + ' kW' : '—'}</div></div>
      <div class="spec" style="grid-column:1/-1"><div class="k">${t('range')}</div><div class="v">${v.range ? Math.round(distDisp(v.range)) + ' ' + S.unit : '—'}</div></div>
    </div>
  </div>`;
}
// fotoğrafı küçültüp dataURL yap (max 640px genişlik)
function resizePhoto(file) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const w = Math.min(640, img.width);
      const h = Math.round(img.height * w / img.width);
      const cv = document.createElement('canvas');
      cv.width = w; cv.height = h;
      cv.getContext('2d').drawImage(img, 0, 0, w, h);
      res(cv.toDataURL('image/jpeg', 0.82));
    };
    img.onerror = rej;
    img.src = URL.createObjectURL(file);
  });
}

// ---------- döviz kuru (frankfurter — ECB) ----------
// Bir para biriminin o günkü TÜM kur tablosunu çek (çift yönlü dönüşüm için)
async function fetchTable(from, date) {
  const day = date && date < new Date().toISOString().slice(0, 10) ? date : 'latest';
  const urls = [
    `https://api.frankfurter.dev/v1/${day}?base=${from}`,
    `https://api.frankfurter.app/${day}?from=${from}`
  ];
  for (const u of urls) {
    try {
      const ctrl = new AbortController();
      const tm = setTimeout(() => ctrl.abort(), 4500);
      const res = await fetch(u, {signal: ctrl.signal});
      clearTimeout(tm);
      if (!res.ok) continue;
      const j = await res.json();
      if (j && j.rates) { j.rates[from] = 1; return {rates: j.rates, date: j.date || day}; }
    } catch (e) { /* sıradaki */ }
  }
  return null;
}
// Kur tablosu eksik kayıtları sessizce tamamla (oturum başına sınırlı)
async function backfillRates() {
  const all = await db.sessions.toArray();
  const need = all.filter(r => r.cur && !r.fxTable);
  const groups = {};
  need.forEach(r => { (groups[r.cur + '|' + r.tarih.slice(0, 10)] ||= []).push(r); });
  let calls = 0;
  for (const key of Object.keys(groups)) {
    if (calls >= 8) break;
    const [cur, date] = key.split('|');
    const got = await fetchTable(cur, date);
    calls++;
    if (got) for (const r of groups[key])
      await db.sessions.update(r.id, {fxTable: got.rates, fxDate: got.date});
  }
}
async function fetchRate(from, to, date) {
  const day = date && date < new Date().toISOString().slice(0, 10) ? date : 'latest';
  const urls = [
    `https://api.frankfurter.dev/v1/${day}?base=${from}&symbols=${to}`,
    `https://api.frankfurter.app/${day}?from=${from}&to=${to}`
  ];
  for (const u of urls) {
    try {
      const ctrl = new AbortController();
      const tm = setTimeout(() => ctrl.abort(), 4000);
      const res = await fetch(u, {signal: ctrl.signal});
      clearTimeout(tm);
      if (!res.ok) continue;
      const j = await res.json();
      const v = j && j.rates && j.rates[to];
      if (v) return {rate: v, date: j.date || day};
    } catch (e) { /* sıradaki kaynak */ }
  }
  return null;
}

// ============================================================
// i18n
// ============================================================
function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  $('d-100-lbl').textContent = t('cost100', {u: S.unit});
  $('d-1km-lbl').textContent = '1 ' + S.unit;
  $('d-1km-lbl2').textContent = '1 ' + S.unit;
  $('c-1km-lbl').textContent = t('ev1', {u: S.unit, x: t('netLbl')});
  $('c-1km-g-lbl').textContent = t('ev1', {u: S.unit, x: t('grossLbl')});
  $('d-100-lbl2').textContent = t('cost100', {u: S.unit});
  $('in-dist-lbl').textContent = t('distance', {u: S.unit});
  $('in-amount-lbl').textContent = t('amount', {s: sym()});
  $('c-price-lbl').textContent = t('fuelPrice', {s: sym()});
  $('c-cons-lbl').textContent = t('fuelCons');
  $('c-ev-lbl').textContent = t('evCost', {u: S.unit});
  $('c-evg-lbl').textContent = t('evCostG', {u: S.unit});
  $('c-ice-lbl').textContent = t('iceCost', {u: S.unit});
  $('c-ice1km-lbl').textContent = t('ice1', {u: S.unit});
  $('c-tcoice1km-lbl').textContent = t('tco1kmIce', {u: S.unit});
  $('c-discfx-lbl').textContent = t('discEffect', {u: S.unit});
  $('c-perkm-lbl').textContent = t('perUnitSaving', {u: S.unit});
  $('c-nf-ev-km-lbl').textContent = 'EV · ' + t('nonFuelKm', {u: S.unit});
  $('c-nf-ice-km-lbl').textContent = t('iceShort') + ' · ' + t('nonFuelKm', {u: S.unit});
  $('c-nf-ev-100-lbl').textContent = 'EV · ' + t('nonFuel100', {u: S.unit});
  $('c-nf-ice-100-lbl').textContent = t('iceShort') + ' · ' + t('nonFuel100', {u: S.unit});
  $('c-nf-ev-yr-lbl').textContent = 'EV · ' + t('nonFuelYear');
  $('c-nf-ice-yr-lbl').textContent = t('iceShort') + ' · ' + t('nonFuelYear');
  $('c-nf-kwh-lbl').textContent = 'EV · ' + t('nonFuelKwh');
  $('c-nf-bar-ice-name').textContent = t('iceShort');
  $('country-search').placeholder = t('country') + '…';
  $('ob-ev-search').placeholder = t('searchCar');
  $('car-search').placeholder = t('searchCar');
  $('btn-adv').textContent =
    $('adv-fields').classList.contains('open') ? t('advancedHide') : t('advanced');
  document.documentElement.lang = S.lang;
}

// ============================================================
// EKRAN GEÇİŞLERİ
// ============================================================
let screen = 'dashboard';
const RENDER = {dashboard: renderDashboard, stats: renderStats, history: renderHistory,
  compare: renderCompare, vehicle: renderVehiclePage, settings: renderSettings};
document.querySelectorAll('nav button[data-page]').forEach(b =>
  b.addEventListener('click', () => showScreen(b.dataset.page)));
function showScreen(name) {
  screen = name;
  document.querySelectorAll('.content .page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('nav button[data-page]').forEach(b =>
    b.classList.toggle('sel', b.dataset.page === name));
  $('page-' + name).classList.add('active');
  RENDER[name]?.();
  document.querySelector('.content').scrollTop = 0;
}

// ============================================================
// ANA SAYFA
// ============================================================
$('d-period').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  S.period = b.dataset.v;
  $('d-period').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  renderDashboard();
});
$('d-vehsel').addEventListener('change', () => { S.dashVeh = $('d-vehsel').value; renderDashboard(); });
$('d-dstat-type').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  S.dstatType = b.dataset.v;
  $('d-dstat-type').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  renderDashboard();
});
$('d-gran').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  S.gran = b.dataset.v;
  $('d-gran').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  renderStats();
});
$('s-vehsel').addEventListener('change', () => { S.dashVeh = $('s-vehsel').value; renderStats(); });

function periodFilter(all) {
  const now = new Date();
  if (S.period === 'week') {
    const from = new Date(now); from.setDate(now.getDate() - 6);
    const key = from.toISOString().slice(0, 10);
    return all.filter(r => r.tarih.slice(0, 10) >= key);
  }
  if (S.period === 'year')
    return all.filter(r => r.tarih.slice(0, 4) === String(now.getFullYear()));
  return all.filter(r => monthKey(r.tarih) === now.toISOString().slice(0, 7));
}
function prevPeriodFilter(all) {
  const now = new Date();
  if (S.period === 'week') {
    const to = new Date(now); to.setDate(now.getDate() - 7);
    const from = new Date(now); from.setDate(now.getDate() - 13);
    const a = from.toISOString().slice(0, 10), b = to.toISOString().slice(0, 10);
    return all.filter(r => { const d = r.tarih.slice(0, 10); return d >= a && d <= b; });
  }
  if (S.period === 'year')
    return all.filter(r => r.tarih.slice(0, 4) === String(now.getFullYear() - 1));
  const p = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const key = p.getFullYear() + '-' + String(p.getMonth() + 1).padStart(2, '0');
  return all.filter(r => monthKey(r.tarih) === key);
}
const vehFilter = (list, vid) => vid ? list.filter(r => String(r.aracId) === vid) : list;
// odometre için araç: seçili > tek araç > varsayılan araç
function pickOdoVeh(vehicles, sel) {
  if (sel) return vehicles.find(v => String(v.id) === sel) || null;
  if (vehicles.length === 1) return vehicles[0];
  return vehicles.find(v => v.id === S.defaultVehicleId) || null;
}
const odoDistOf = v => (v && v.kmStart != null && v.kmNow > v.kmStart) ? v.kmNow - v.kmStart : 0;
const vehName = v => v ? (v.brand ? v.brand + ' ' + v.model : v.ad) : '';

async function renderDashboard() {
  const vehicles = (await db.vehicles.toArray()).filter(v => !v.archived);
  // araç filtresi seçeneği (2+ araçta görünür, tek araçta adını gösterir)
  const dsel = $('d-vehsel');
  if (vehicles.length > 1) {
    const cur = S.dashVeh;
    dsel.style.display = '';
    dsel.innerHTML = `<option value="">${t('allVehicles')}</option>` +
      vehicles.map(v => `<option value="${v.id}">${esc(vehName(v))}</option>`).join('');
    dsel.value = cur;
  } else {
    dsel.style.display = vehicles.length ? '' : 'none';
    dsel.innerHTML = vehicles.length ? `<option value="">${esc(vehName(vehicles[0]))}</option>` : '';
    S.dashVeh = '';
  }

  const allRaw = await db.sessions.toArray();
  const all = vehFilter(allRaw, S.dashVeh);
  const cur = periodFilter(all);

  $('d-period-lbl').textContent =
    t(S.period === 'week' ? 'periodWeek' : S.period === 'year' ? 'periodYear' : 'periodMonth');

  const net = cur.reduce((s, r) => s + amtB(r), 0);
  const sav = cur.reduce((s, r) => s + savB(r), 0);
  const gross = net + sav;
  const kwh = cur.reduce((s, r) => s + r.kwh, 0);
  const wd = cur.filter(r => r.mesafeKm > 0);
  const distKm = wd.reduce((s, r) => s + r.mesafeKm, 0);
  const netD = wd.reduce((s, r) => s + amtB(r), 0);
  const grossD = netD + wd.reduce((s, r) => s + savB(r), 0);
  const f = distFactor();

  $('d-total').textContent = money(net);
  $('d-gross').textContent = money(gross);
  $('d-savings').textContent = '−' + money(sav) + ' ' + t('savings');
  // önceki döneme göre değişim
  const prev = prevPeriodFilter(all).reduce((s, r) => s + amtB(r), 0);
  const dEl = $('d-delta');
  if (prev > 0) {
    const pct = Math.round((net - prev) / prev * 100);
    dEl.textContent = (pct >= 0 ? '▲ +' : '▼ ') + pct + '% ' + t('prevPeriod');
    dEl.className = 'delta ' + (pct >= 0 ? 'up' : 'down');
  } else { dEl.textContent = ''; dEl.className = 'delta'; }
  $('d-avg').textContent = kwh ? fm(sym(), (net / kwh).toFixed(2)) : '—';
  $('d-avg-g').textContent = kwh ? fm(sym(), (gross / kwh).toFixed(2)) : '—';
  const fill100 = (npk, gpk) => {   // npk/gpk: birim başına (km) net/brüt
    $('d-1km').textContent = money2(npk * f);
    $('d-1km-g').textContent = money2(gpk * f);
    $('d-100').textContent = money2(npk * 100 * f);
    $('d-100-g').textContent = money2(gpk * 100 * f);
  };
  if (distKm >= 20) {
    fill100(netD / distKm, grossD / distKm);
  } else {
    // kayıt mesafesi yok → kilometre sayacından genel (tüm zamanlar) değer
    const oV = pickOdoVeh(vehicles, S.dashVeh);
    const oDist = odoDistOf(oV);
    if (oDist >= 20) {
      const allConv = all.filter(isConv);
      const aNet = allConv.reduce((s, r) => s + amtB(r), 0);
      const aGross = aNet + allConv.reduce((s, r) => s + savB(r), 0);
      fill100(aNet / oDist, aGross / oDist);
    } else {
      ['d-1km','d-1km-g','d-100','d-100-g'].forEach(id => $(id).textContent = '—');
    }
  }
  $('d-kwh').textContent = kwh.toLocaleString('tr-TR', {maximumFractionDigits: 0});
  $('d-sess').textContent = cur.length + ' / ' + new Set(cur.map(r => r.firma)).size;
  $('d-disc').textContent = money(sav);
  $('d-free').textContent = cur.filter(r => r.free).length;

  const now = new Date();

  // odometre kutuları (tek araç ya da seçili araç)
  const odoV = pickOdoVeh(vehicles, S.dashVeh);
  const odoWrap = $('d-odo-wrap');
  if (odoV && odoV.kmNow) {
    odoWrap.style.display = '';
    $('d-odo').textContent = Math.round(distDisp(odoV.kmNow)).toLocaleString('tr-TR') + ' ' + S.unit;
    $('d-odo-total').textContent = odoV.kmStart != null
      ? Math.round(distDisp(odoV.kmNow - odoV.kmStart)).toLocaleString('tr-TR') + ' ' + S.unit : '—';
  } else odoWrap.style.display = 'none';

  // detay: ortalama süre & SoC aralığı (Tümü/DC/AC filtresiyle)
  const dsAll = S.dstatType ? all.filter(r => r.tip === S.dstatType) : all;
  const durs = dsAll.filter(r => r.dur > 0);
  $('d-dur').textContent = durs.length
    ? (() => { const m = Math.round(durs.reduce((s, r) => s + r.dur, 0) / durs.length);
        return (m >= 60 ? Math.floor(m / 60) + ' ' + t('hours') + ' ' : '') + (m % 60) + ' ' + t('minutes'); })()
    : '—';
  const socs = dsAll.filter(r => r.socB != null && r.socA != null);
  $('d-soc').textContent = socs.length
    ? '%' + Math.round(socs.reduce((s, r) => s + r.socB, 0) / socs.length) +
      ' → %' + Math.round(socs.reduce((s, r) => s + r.socA, 0) / socs.length)
    : '—';
  // ort. şarj gücü (kWh/saat) — süre girilmiş kayıtlardan
  const powKwh = durs.reduce((s, r) => s + r.kwh, 0);
  const powMin = durs.reduce((s, r) => s + r.dur, 0);
  $('d-power').textContent = powMin > 0 ? (powKwh / (powMin / 60)).toFixed(1) + ' kWh/h' : '—';

  // yıllık karşılaştırma (bu yıl vs geçen yıl — tüm zamanlar, dönem seçiciden bağımsız)
  const thisY = String(now.getFullYear()), lastY = String(now.getFullYear() - 1);
  const yThisArr = all.filter(r => r.tarih.slice(0, 4) === thisY);
  const yLastArr = all.filter(r => r.tarih.slice(0, 4) === lastY);
  const ySumThis = yThisArr.reduce((s, r) => s + amtB(r), 0), ySumLast = yLastArr.reduce((s, r) => s + amtB(r), 0);
  const yKwhThis = yThisArr.reduce((s, r) => s + r.kwh, 0), yKwhLast = yLastArr.reduce((s, r) => s + r.kwh, 0);
  const yPriceThis = yKwhThis ? ySumThis / yKwhThis : 0, yPriceLast = yKwhLast ? ySumLast / yKwhLast : 0;
  $('d-yr-spend').textContent = money(ySumThis);
  $('d-yr-kwh').textContent = yKwhThis.toLocaleString('tr-TR', {maximumFractionDigits: 0}) + ' kWh';
  $('d-yr-price').textContent = yKwhThis ? fm(sym(), yPriceThis.toFixed(2)) : '—';
  const yDelta = (curV, prevV, id) => {
    const el = $(id);
    if (prevV > 0) {
      const pct = Math.round((curV - prevV) / prevV * 100);
      el.textContent = (pct >= 0 ? '▲ +' : '▼ ') + pct + '% ' + t('vsLastYear');
      el.style.color = pct >= 0 ? 'var(--red)' : 'var(--accent-dark)';
    } else { el.textContent = ''; }
  };
  yDelta(ySumThis, ySumLast, 'd-yr-spend-d');
  yDelta(yKwhThis, yKwhLast, 'd-yr-kwh-d');
  yDelta(yPriceThis, yPriceLast, 'd-yr-price-d');

  const sorted = [...all].sort((a, b) => b.tarih.localeCompare(a.tarih)).slice(0, 3);
  $('d-recent').innerHTML = sorted.length
    ? sorted.map(r => rowHTML(r, false)).join('')
    : `<div class="empty">${t('noData')}</div>`;
  $('d-recent').querySelectorAll('.crow').forEach(el =>
    el.addEventListener('click', () => openAdd(+el.dataset.id)));
}
$('d-viewall').addEventListener('click', () => showScreen('history'));

// ============================================================
// İSTATİSTİK (ana sayfadan taşınan grafikler + dağılımlar)
// ============================================================
async function renderStats() {
  const vehicles = (await db.vehicles.toArray()).filter(v => !v.archived);
  const ssel = $('s-vehsel');
  if (vehicles.length > 1) {
    ssel.style.display = '';
    ssel.innerHTML = `<option value="">${t('allVehicles')}</option>` +
      vehicles.map(v => `<option value="${v.id}">${esc(vehName(v))}</option>`).join('');
    ssel.value = S.dashVeh;
  } else {
    ssel.style.display = vehicles.length ? '' : 'none';
    ssel.innerHTML = vehicles.length ? `<option value="">${esc(vehName(vehicles[0]))}</option>` : '';
  }

  const all = vehFilter(await db.sessions.toArray(), S.dashVeh);

  // harcama grafiği — kendi Hafta/Ay/Yıl seçicisiyle
  const now = new Date();
  const bars = [];
  if (S.gran === 'week') {
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now); d.setDate(now.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      bars.push({
        label: DAYS[S.lang][(d.getDay() + 6) % 7],
        year: String(d.getFullYear()),
        sum: all.filter(r => r.tarih.slice(0, 10) === key).reduce((s, r) => s + amtB(r), 0)
      });
    }
  } else if (S.gran === 'year') {
    for (let i = 4; i >= 0; i--) {
      const y = String(now.getFullYear() - i);
      bars.push({label: y, year: y,
        sum: all.filter(r => r.tarih.slice(0, 4) === y).reduce((s, r) => s + amtB(r), 0)});
    }
  } else {
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
      bars.push({
        label: MONTHS[S.lang][d.getMonth()].slice(0, 3),
        year: String(d.getFullYear()),
        sum: all.filter(r => monthKey(r.tarih) === key).reduce((s, r) => s + amtB(r), 0)
      });
    }
  }
  const maxM = Math.max(1, ...bars.map(b => b.sum));
  $('d-months').innerHTML = bars.map(b =>
    `<div class="mb" data-y="${b.year}" style="cursor:pointer">
      <div class="amt">${b.sum ? money(b.sum) : ''}</div>
      <div class="bar" style="height:${6 + Math.round(b.sum / maxM * 66)}px"></div>
      <div class="m">${b.label}</div>
    </div>`).join('');
  $('d-months').querySelectorAll('.mb').forEach(el =>
    el.addEventListener('click', () => { histYear = el.dataset.y; showScreen('history'); }));

  // haftanın günlerine göre dağılım (tüm zamanlar, Pzt→Paz)
  const wdSum = [0, 0, 0, 0, 0, 0, 0];
  all.forEach(r => {
    const [ry, rm, rd] = r.tarih.slice(0, 10).split('-').map(Number);
    const day = (new Date(ry, rm - 1, rd).getDay() + 6) % 7;
    wdSum[day] += amtB(r);
  });
  const maxW = Math.max(1, ...wdSum);
  $('d-weekdays').innerHTML = wdSum.map((v, i) =>
    `<div class="mb">
      <div class="amt">${v ? money(v) : ''}</div>
      <div class="bar" style="height:${6 + Math.round(v / maxW * 66)}px"></div>
      <div class="m">${DAYS[S.lang][i]}</div>
    </div>`).join('');

  // firma dağılımı
  const by = {};
  all.forEach(r => {
    (by[r.firma] ||= {firma: r.firma, total: 0, kwh: 0, count: 0});
    by[r.firma].total += amtB(r); by[r.firma].kwh += r.kwh; by[r.firma].count++;
  });
  const rows = Object.values(by).sort((a, b) => b.total - a.total).slice(0, 6);
  const maxF = Math.max(1, ...rows.map(r => r.total));
  $('d-firms').innerHTML = rows.length ? rows.map(r =>
    `<div class="cmp">
      <div class="cmp-head">
        <div class="avatar" style="background:${colorFor(r.firma)}">${esc(r.firma.charAt(0).toUpperCase())}</div>
        <div class="mid">
          <div class="name">${esc(r.firma)}</div>
          <div class="sub">${r.count} ${t('sessions')} · ${r.kwh ? (r.total / r.kwh).toFixed(2) : '0.00'} ${esc(sym())}/kWh</div>
        </div>
        <div class="total">${money(r.total)}</div>
      </div>
      <div class="track"><div class="fill" style="width:${Math.round(r.total / maxF * 100)}%"></div></div>
    </div>`).join('') : `<div class="empty">${t('noData')}</div>`;

  // şarj tipi donut (kWh bazında: DC / AC / Ev)
  const home = t('homeChip');
  const segs = [
    {name: 'DC', kwh: all.filter(r => r.tip === 'DC' && r.firma !== home).reduce((s, r) => s + r.kwh, 0), col: '#16A34A'},
    {name: 'AC', kwh: all.filter(r => r.tip !== 'DC' && r.firma !== home).reduce((s, r) => s + r.kwh, 0), col: '#1B5FAA'},
    {name: home, kwh: all.filter(r => r.firma === home).reduce((s, r) => s + r.kwh, 0), col: '#7DC855'}
  ].filter(x => x.kwh > 0);
  const tot = segs.reduce((s, x) => s + x.kwh, 0) || 1;
  let off = 25;
  const trackCol = getComputedStyle(document.documentElement).getPropertyValue('--track').trim() || '#E3EAE4';
  $('d-donut').innerHTML =
    `<circle cx="21" cy="21" r="15.915" fill="none" stroke="${trackCol}" stroke-width="5"></circle>` +
    segs.map(x => {
      const p = x.kwh / tot * 100;
      const el = `<circle cx="21" cy="21" r="15.915" fill="none" stroke="${x.col}" stroke-width="5"
        stroke-dasharray="${p} ${100 - p}" stroke-dashoffset="${off}" stroke-linecap="butt"></circle>`;
      off -= p;
      return el;
    }).join('');
  $('d-donut-legend').innerHTML = segs.map(x =>
    `<div class="li"><span class="dot" style="background:${x.col}"></span>${esc(x.name)}
     <span class="lv">${Math.round(x.kwh)} kWh · %${Math.round(x.kwh / tot * 100)}</span></div>`).join('') ||
    `<div class="li" style="color:var(--faint)">${t('noData')}</div>`;

  // en çok kazandıran bankalar
  const bB = {};
  all.forEach(r => { if (r.banka) {
    (bB[r.banka] ||= {sav: 0, n: 0});
    bB[r.banka].sav += savB(r); bB[r.banka].n++;
  }});
  const banksTop = Object.entries(bB).sort((a, b) => b[1].sav - a[1].sav).slice(0, 5);
  $('d-banks').innerHTML = banksTop.length ? banksTop.map(([name, x], i) =>
    `<div class="tl"><span class="rank">${i + 1}</span>
      <span class="tn">${esc(name)}<div class="ts">${x.n} ${t('sessions')}</div></span>
      <span class="tv" style="color:var(--accent-dark)">−${money(x.sav)}</span></div>`).join('')
    : `<div class="tl" style="color:var(--faint)">${t('noData')}</div>`;

  // en çok lokasyonlar
  const bL = {};
  all.forEach(r => { if (r.loc) {
    (bL[r.loc] ||= {n: 0, tl: 0});
    bL[r.loc].n++; bL[r.loc].tl += amtB(r);
  }});
  const locsTop = Object.entries(bL).sort((a, b) => b[1].n - a[1].n).slice(0, 5);
  $('d-locs').innerHTML = locsTop.length ? locsTop.map(([name, x], i) =>
    `<div class="tl"><span class="rank">${i + 1}</span>
      <span class="tn">${esc(name)}<div class="ts">${money(x.tl)}</div></span>
      <span class="tv">${x.n} ${t('sessions')}</span></div>`).join('')
    : `<div class="tl" style="color:var(--faint)">${t('noData')}</div>`;
}

function rowHTML(r, withDelete) {
  const s = savingsOf(r);
  const cs = symOf(r.cur || S.currency);
  return `<div class="crow" data-id="${r.id}">
    <div class="avatar" style="background:${colorFor(r.firma)}">${esc(r.firma.charAt(0).toUpperCase())}</div>
    <div class="mid">
      <div class="name">${esc(r.firma)}</div>
      <div class="sub">${shortDate(r.tarih)} · ${r.kwh} kWh · ${r.tip || 'DC'}${r.mesafeKm ? ' · ' + Math.round(distDisp(r.mesafeKm)) + ' ' + S.unit : ''}</div>
    </div>
    <div class="right">
      <div class="amt">${r.free ? '<span class="free-tag">' + t('free') + '</span>' : fm(cs, Math.round(r.odenen).toLocaleString('tr-TR'))}</div>
      <div class="sav">${s > 0 ? '−' + fm(cs, Math.round(s).toLocaleString('tr-TR')) : ''}</div>
    </div>
    ${withDelete ? `<button class="del" data-del="${r.id}">×</button>` : ''}
  </div>`;
}

// ============================================================
// GEÇMİŞ
// ============================================================
async function renderHistory() {
  const all = await db.sessions.toArray();
  const vehicles = await db.vehicles.toArray();
  const sorted = [...all].sort((a, b) => b.tarih.localeCompare(a.tarih));

  const years = [...new Set(sorted.map(r => r.tarih.slice(0, 4)))].sort().reverse();
  const firms = [...new Set(sorted.map(r => r.firma))].sort((a, b) => a.localeCompare(b));
  const banks = [...new Set(sorted.map(r => r.banka).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  const locs2 = [...new Set(sorted.map(r => r.loc).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  const keep = (sel, opts) => opts.includes(sel.value) ? sel.value : '';
  const fy = $('f-year'), ff = $('f-firm'), ft = $('f-type'), fv = $('f-veh'),
        fb = $('f-bank'), fl = $('f-loc');
  let vy = keep(fy, years); const vf = keep(ff, firms);
  const vb = keep(fb, banks), vl = keep(fl, locs2);
  if (histYear) { if (years.includes(histYear)) vy = histYear; histYear = null; }
  const vt = ['DC','AC','free'].includes(ft.value) ? ft.value : '';
  const vv = vehicles.some(v => String(v.id) === fv.value) ? fv.value : '';
  fy.innerHTML = `<option value="">${t('allYears')}</option>` + years.map(y => `<option>${y}</option>`).join('');
  ff.innerHTML = `<option value="">${t('allFirms')}</option>` + firms.map(f => `<option>${esc(f)}</option>`).join('');
  ft.innerHTML = `<option value="">${t('allTypes')}</option><option value="DC">DC</option><option value="AC">AC</option><option value="free">${t('free')}</option>`;
  fv.style.display = vehicles.length > 1 ? '' : 'none';
  fv.innerHTML = `<option value="">${t('allVehicles')}</option>` +
    vehicles.map(v => `<option value="${v.id}">${esc(vehName(v))}</option>`).join('');
  fb.style.display = banks.length ? '' : 'none';
  fb.innerHTML = `<option value="" hidden>${t('bank')}</option><option value="">${t('viewAll')}</option>` +
    banks.map(x => `<option>${esc(x)}</option>`).join('');
  fl.style.display = locs2.length ? '' : 'none';
  fl.innerHTML = `<option value="" hidden>${t('location')}</option><option value="">${t('viewAll')}</option>` +
    locs2.map(x => `<option>${esc(x)}</option>`).join('');
  fy.value = vy; ff.value = vf; ft.value = vt; fv.value = vv; fb.value = vb; fl.value = vl;

  const rows = sorted.filter(r =>
    (!vy || r.tarih.slice(0, 4) === vy) &&
    (!vf || r.firma === vf) &&
    (!vt || (vt === 'free' ? r.free : r.tip === vt)) &&
    (!vv || String(r.aracId) === vv) &&
    (!vb || r.banka === vb) &&
    (!vl || r.loc === vl));

  const box = $('h-groups');
  if (!rows.length) { box.innerHTML = `<div class="empty">${t('noData')}</div>`; return; }

  const groups = [];
  let last = null;
  rows.forEach(r => {
    const key = monthKey(r.tarih);
    if (key !== last) {
      const [y, m] = key.split('-');
      groups.push({label: MONTHS[S.lang][+m - 1] + ' ' + y, items: []});
      last = key;
    }
    groups[groups.length - 1].items.push(r);
  });
  box.innerHTML = groups.map(g =>
    `<div class="month-group">
      <div class="section-lbl">${g.label}</div>
      <div class="rows">${g.items.map(r => rowHTML(r, true)).join('')}</div>
    </div>`).join('');

  box.querySelectorAll('[data-del]').forEach(b =>
    b.addEventListener('click', async e => {
      e.stopPropagation();
      if (!confirm(t('deleteAsk'))) return;
      const delRec = await db.sessions.get(+b.dataset.del);
      await db.sessions.delete(+b.dataset.del);
      if (delRec) await bumpVehicleKm(delRec.aracId, -(delRec.mesafeKm || 0));
      toast(t('deleted'));
      renderHistory();
    }));
  box.querySelectorAll('.crow').forEach(el =>
    el.addEventListener('click', () => openAdd(+el.dataset.id)));
}
['f-year','f-firm','f-type','f-veh','f-bank','f-loc'].forEach(id => $(id).addEventListener('change', renderHistory));
let histYear = null;

// ============================================================
// KIYASLA
// ============================================================
$('c-fuel').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  $('c-fuel').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  $('c-hybrid-note').style.display = b.dataset.v === 'hybrid' ? '' : 'none';
});
$('c-vehsel').addEventListener('change', () => { S.cmpVeh = $('c-vehsel').value; renderCompare(); });
$('c-calc').addEventListener('click', async () => {
  const price = pf($('c-price').value);
  const cons = pf($('c-cons').value);
  if (!price || !cons || price <= 0 || cons <= 0) return;
  S.cmp = {fuel: $('c-fuel').querySelector('.sel').dataset.v, price, cons,
    icefix: Math.max(0, pf($('c-icefix').value) || 0),
    prorate: $('c-prorate').checked};
  await saveSetting('cmp', S.cmp);
  renderCompare();
});

async function renderCompare() {
  const vehicles = (await db.vehicles.toArray()).filter(v => !v.archived);
  const wrap = $('wrap-c-veh');
  wrap.style.display = vehicles.length > 1 ? '' : 'none';
  if (vehicles.length > 1) {
    const cur = S.cmpVeh;
    $('c-vehsel').innerHTML = `<option value="">${t('allVehicles')}</option>` +
      vehicles.map(v => `<option value="${v.id}">${esc(vehName(v))}</option>`).join('');
    $('c-vehsel').value = cur;
  }
  if (S.cmp) {
    $('c-price').value = String(S.cmp.price).replace('.', ',');
    $('c-cons').value = String(S.cmp.cons).replace('.', ',');
    $('c-icefix').value = S.cmp.icefix ? String(S.cmp.icefix).replace('.', ',') : '';
    $('c-prorate').checked = S.cmp.prorate !== false;
    $('c-fuel').querySelectorAll('button').forEach(x =>
      x.classList.toggle('sel', x.dataset.v === S.cmp.fuel));
    $('c-hybrid-note').style.display = S.cmp.fuel === 'hybrid' ? '' : 'none';
  }

  // ---- Araç giderleri: hesaplamaya dahil edilir (liste/kategori UI'ı Aracım sekmesinde) ----
  const exAll = await db.expenses.toArray();
  const ex = S.cmpVeh
    ? exAll.filter(e => String(e.aracId) === S.cmpVeh || !e.aracId)
    : exAll;

  const box = $('c-result');
  if (!S.cmp) { box.style.display = 'none'; return; }

  const all = vehFilter(await db.sessions.toArray(), S.cmpVeh);
  let wd = all.filter(r => r.mesafeKm > 0);
  let distKm = wd.reduce((s, r) => s + r.mesafeKm, 0);
  let net = wd.reduce((s, r) => s + amtB(r), 0);
  let gross = net + wd.reduce((s, r) => s + savB(r), 0);
  // kayıt bazlı mesafe yoksa: kilometre sayacı (seçili araç ya da tek araç)
  const odoV2 = pickOdoVeh(vehicles, S.cmpVeh);
  const odoDist = odoDistOf(odoV2);
  let odoMode = false;
  if (distKm < 20 && odoDist >= 20) {
    odoMode = true;
    distKm = odoDist;
    net = all.filter(isConv).reduce((s, r) => s + amtB(r), 0);
    gross = net + all.filter(isConv).reduce((s, r) => s + savB(r), 0);
    // grafik/aylık dağıtım için: mesafeyi harcamayla orantılı paylaştır
    wd = all.filter(isConv).map(r =>
      ({...r, mesafeKm: net > 0 ? amtB(r) / net * odoDist : 0}));
  }
  $('c-dist-src').textContent = odoMode ? t('distFromOdo') : (distKm >= 20 ? t('distFromRecords') : '');
  box.style.display = '';
  if (distKm < 20) {
    $('c-ev').textContent = '—'; $('c-ice').textContent = '—';
    $('c-ev-g').textContent = '—'; $('c-disc-fx').textContent = '—';
    $('c-1km').textContent = '—'; $('c-1km-g').textContent = '—';
    $('c-ice1km').textContent = '—';
    ['c-exptot','c-icefixtot','c-tcoev','c-tcoice','c-tco1km','c-tcoice1km'].forEach(id => $(id).textContent = '—');
    $('c-perkm').textContent = t('needData');
    $('c-perkm').style.fontSize = '15px';
    $('c-per100').textContent = '';
    ['c-nf-ev-km','c-nf-ice-km','c-nf-ev-100','c-nf-ice-100','c-nf-ev-yr','c-nf-ice-yr','c-nf-kwh','c-nf-diff']
      .forEach(id => $(id).textContent = '—');
    $('c-nf-diff-pill').textContent = '';
    $('c-nf-bar-ev').style.width = '0%'; $('c-nf-bar-ice').style.width = '0%';
    $('c-nf-bar-ev-lbl').textContent = ''; $('c-nf-bar-ice-lbl').textContent = '';
    return;
  }
  $('c-perkm').style.fontSize = '28px';

  const f = distFactor();                       // 100 birim = 100*f km
  const evNetPerKm = net / distKm;
  const evGrossPerKm = gross / distKm;
  const icePerKm = S.cmp.price * S.cmp.cons / 100;

  $('c-1km').textContent = money2(evNetPerKm * f);
  $('c-ice1km').textContent = money2(icePerKm * f);
  $('c-1km-g').textContent = money2(evGrossPerKm * f);
  $('c-ev').textContent = money2(evNetPerKm * 100 * f);
  $('c-ev-g').textContent = money2(evGrossPerKm * 100 * f);
  $('c-ice').textContent = money2(icePerKm * 100 * f);
  $('c-disc-fx').textContent = '−' + money2((evGrossPerKm - evNetPerKm) * 100 * f);
  $('c-perkm').textContent = money2((icePerKm - evNetPerKm) * f) + ' / ' + S.unit;
  $('c-per100').textContent = t('per100', {v: money((icePerKm - evNetPerKm) * 100 * f), u: S.unit});

  // --- bugüne kadar kümülatif: EV gerçek vs yakıtlı (aynı km) ---
  const iceTot = distKm * icePerKm;
  $('c-dist-lbl').textContent = t('totalDist');
  $('c-dist').textContent = Math.round(distDisp(distKm)).toLocaleString('tr-TR') + ' ' + S.unit;
  $('c-evtot').textContent = money(net);
  $('c-icetot').textContent = money(iceTot);
  $('c-savetot').textContent = '+' + money(Math.max(0, iceTot - net));

  // kayıt bazlı kümülatif çizgiler (ilk kayıttan itibaren, son 14 nokta)
  const seq = [...wd].sort((a, b) => a.tarih.localeCompare(b.tarih));
  let cumEv = 0, cumIce = 0;
  const ptsEvAll = [], ptsIceAll = [], labelsAll = [];
  seq.forEach(r => {
    cumEv += amtB(r);
    cumIce += r.mesafeKm * icePerKm;
    ptsEvAll.push(cumEv); ptsIceAll.push(cumIce);
    labelsAll.push(shortDate(r.tarih));
  });
  const cut = Math.max(0, ptsEvAll.length - 14);
  drawLineChart('c-line', labelsAll.slice(cut), [
    {pts: ptsEvAll.slice(cut), color: '#1C8742'},
    {pts: ptsIceAll.slice(cut), color: '#1B5FAA'}
  ]);

  // ---- TOPLAM SAHİP OLMA MALİYETİ (şarj + giderler) ----
  const expReal = ex.reduce((s, e) => s + expB(e), 0);
  const dates = [...all.map(r => r.tarih.slice(0, 10)), ...ex.map(e => e.tarih)].sort();
  const days = dates.length > 1
    ? Math.max(30, (new Date(dates[dates.length - 1]) - new Date(dates[0])) / 864e5) : 365;
  const yearly = ['tax', 'insurance'];          // doğası gereği yıllık kalemler
  const pr = S.cmp.prorate !== false && days < 365 ? days / 365 : 1;
  const expTot = ex.reduce((s, e) =>
    s + expB(e) * (yearly.includes(e.tur) ? pr : 1), 0);
  const tcoEv = net + expTot;
  const iceFix = (S.cmp.icefix || 0) * days / 365;
  const tcoIce = iceTot + iceFix;
  $('c-exptot').textContent = money(expTot);
  $('c-icefixtot').textContent = money(iceFix);
  $('c-tcoev').textContent = money(tcoEv);
  $('c-tco1km-lbl').textContent = t('tco1km', {u: S.unit});
  $('c-tco1km').textContent = money2(tcoEv / distKm * f);
  $('c-tcoice1km-lbl').textContent = t('tco1kmIce', {u: S.unit});
  $('c-tcoice1km').textContent = money2(tcoIce / distKm * f);
  $('c-tcoice').textContent = money(tcoIce);
  const tcoSave = tcoIce - tcoEv;
  $('c-tcosave').textContent = (tcoSave >= 0 ? '+' : '') + money(tcoSave);
  $('c-tcosave').style.color = tcoSave >= 0 ? 'var(--accent-dark)' : 'var(--red)';
  $('c-tcopill').textContent = t('per100', {v: money(tcoSave / distKm * 100 * f), u: S.unit});
  $('c-tco-note').textContent = t('tcoNote', {d: Math.round(days), f: money(iceFix)}) +
    (pr < 1 ? ' ' + t('prorateNote', {p: Math.round(pr * 100), r: money(expReal)}) : '');

  // ---- Yakıt dışı gider kıyaslaması (EV vs Yakıtlı) ----
  // Yakıtlı aracın yıllık sabit gideri girilmemişse (opsiyonel alan) kıyas anlamsız olur — gizle.
  if (!S.cmp.icefix) { $('c-nf-wrap').style.display = 'none'; return; }
  $('c-nf-wrap').style.display = '';
  const kwhSum = all.reduce((s, r) => s + (r.kwh || 0), 0);
  const nfEvPerKm = expTot / distKm;
  const nfIcePerKm = iceFix / distKm;
  $('c-nf-ev-km').textContent = money2(nfEvPerKm * f);
  $('c-nf-ice-km').textContent = money2(nfIcePerKm * f);
  $('c-nf-ev-100').textContent = money2(nfEvPerKm * 100 * f);
  $('c-nf-ice-100').textContent = money2(nfIcePerKm * 100 * f);
  const nfEvYear = expTot / days * 365;
  const nfIceYear = S.cmp.icefix || 0;
  $('c-nf-ev-yr').textContent = money(nfEvYear);
  $('c-nf-ice-yr').textContent = money(nfIceYear);
  $('c-nf-kwh').textContent = kwhSum ? money2(expTot / kwhSum) + '/kWh' : '—';
  const nfDiff = nfIceYear - nfEvYear;
  $('c-nf-diff').textContent = (nfDiff >= 0 ? '+' : '') + money(nfDiff);
  $('c-nf-diff').style.color = nfDiff >= 0 ? 'var(--accent-dark)' : 'var(--red)';
  $('c-nf-diff-pill').textContent = t('per100', {v: money((nfIcePerKm - nfEvPerKm) * 100 * f), u: S.unit});
  $('c-nf-bar-ev-lbl').textContent = money(nfEvYear);
  $('c-nf-bar-ice-lbl').textContent = money(nfIceYear);
  const nfMax = Math.max(1, nfEvYear, nfIceYear);
  $('c-nf-bar-ev').style.width = Math.round(nfEvYear / nfMax * 100) + '%';
  $('c-nf-bar-ice').style.width = Math.round(nfIceYear / nfMax * 100) + '%';
}

// ---------- basit SVG çizgi grafik ----------
function drawLineChart(id, labels, series) {
  const W = 340, H = 170, padL = 8, padR = 8, padT = 12, padB = 22;
  const n = labels.length;
  const svg = $(id);
  if (n < 2) { svg.innerHTML = ''; return; }
  const maxV = Math.max(1, ...series.flatMap(s => s.pts));
  const x = i => padL + i * (W - padL - padR) / (n - 1);
  const y = v => padT + (1 - v / maxV) * (H - padT - padB);
  // yatay kılavuz çizgileri
  const gCol = getComputedStyle(document.documentElement).getPropertyValue('--track').trim() || '#E3EAE4';
  let out = [0.25, 0.5, 0.75, 1].map(f =>
    `<line x1="${padL}" y1="${y(maxV * f)}" x2="${W - padR}" y2="${y(maxV * f)}"
      stroke="${gCol}" stroke-width="1"/>`).join('');
  series.forEach(s => {
    const d = s.pts.map((v, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1)).join(' ');
    // dolgu (yalnızca ilk seri — EV)
    out += `<path d="${d}" pathLength="1" fill="none" stroke="${s.color}" stroke-width="2.5"
      stroke-linecap="round" stroke-linejoin="round"/>`;
    out += s.pts.map((v, i) =>
      `<circle cx="${x(i).toFixed(1)}" cy="${y(v).toFixed(1)}" r="3" fill="${s.color}"/>`).join('');
  });
  // etiketler (en fazla 6 tanesini göster)
  const step = Math.ceil(n / 6);
  out += labels.map((l, i) => i % step ? '' :
    `<text x="${x(i).toFixed(1)}" y="${H - 6}" font-size="9" fill="#8B918C"
      text-anchor="middle" font-family="inherit">${l}</text>`).join('');
  svg.innerHTML = out;
}

// ============================================================
// AYARLAR
// ============================================================
async function renderSettings() {
  $('app-version').textContent = APP_VERSION + ' · ' + APP_DATE;
  const c = COUNTRIES.find(x => x[0] === S.country);
  $('set-country-val').textContent = c ? c[1] + ' ' + c[2] : '—';

  const curs = [...new Set(COUNTRIES.map(x => x[3]))].sort();
  $('set-currency').innerHTML = curs.map(k =>
    `<option value="${k}" ${k === S.currency ? 'selected' : ''}>${k} (${symOf(k)})</option>`).join('');
  $('set-unit').querySelectorAll('button').forEach(b =>
    b.classList.toggle('sel', b.dataset.v === S.unit));
  $('set-lang').innerHTML = Object.keys(LANG_NAMES).map(k =>
    `<option value="${k}" ${k === S.lang ? 'selected' : ''}>${LANG_NAMES[k]}</option>`).join('');
  $('set-adv').checked = !!S.advOpen;
  $('set-theme').querySelectorAll('button').forEach(b =>
    b.classList.toggle('sel', b.dataset.v === (S.theme || 'light')));
  renderBankCountries();
}

// ============================================================
// ARACIM (araç listesi + araç giderleri)
// ============================================================
async function renderVehiclePage() {
  const allV = await db.vehicles.toArray();
  const vehicles = allV.filter(v => !v.archived);
  const archived = allV.filter(v => v.archived);
  $('set-vehicles').innerHTML = vehicles.length ? vehicles.map(v => {
    const kmTxt = v.kmNow ? Math.round(distDisp(v.kmNow)).toLocaleString('tr-TR') + ' ' + S.unit : '';
    const sub = [v.batt ? `${v.trim || ''} · ${v.batt} kWh` : '', kmTxt].filter(Boolean).join(' · ');
    const isDef = v.id === S.defaultVehicleId || (!S.defaultVehicleId && vehicles[0].id === v.id);
    const thumb = v.photo ? `<img class="vthumb" src="${v.photo}" alt="">` : '';
    return `<li data-vid="${v.id}">
      <button class="star ${isDef ? 'on' : ''}" data-star="${v.id}" title="varsayılan">★</button>
      ${thumb}
      <div class="vn">${esc(vehName(v))}<div class="vd">${esc(sub)}</div></div>
      <button class="cam" data-odo="${v.id}" title="kilometre güncelle" style="font-size:11px;font-weight:800;width:36px">km✎</button>
      <button class="cam" data-cam="${v.id}" title="fotoğraf">📷</button>
      <button class="rm" data-rm="${v.id}" title="arşivle">×</button>
    </li>`;
  }).join('') : `<li style="color:var(--faint);font-weight:400">${t('noData')}</li>`;

  $('arch-lbl').style.display = archived.length ? '' : 'none';
  $('set-archived').innerHTML = archived.map(v =>
    `<li><div class="vn">${esc(vehName(v))}<div class="vd">${t('archivedTag')}</div></div>
     <button class="undo" data-undo="${v.id}">${t('restore')}</button></li>`).join('');
  $('set-archived').querySelectorAll('[data-undo]').forEach(b =>
    b.addEventListener('click', async () => {
      await db.vehicles.update(+b.dataset.undo, {archived: false});
      renderVehiclePage();
    }));

  $('set-vehicles').querySelectorAll('[data-star]').forEach(b =>
    b.addEventListener('click', async e => {
      e.stopPropagation();
      S.defaultVehicleId = +b.dataset.star;
      await saveSetting('defaultVehicleId', S.defaultVehicleId);
      renderVehiclePage();
    }));
  $('set-vehicles').querySelectorAll('[data-cam]').forEach(b =>
    b.addEventListener('click', e => {
      e.stopPropagation();
      photoTargetVid = +b.dataset.cam;
      $('car-photo').click();
    }));
  $('set-vehicles').querySelectorAll('[data-rm]').forEach(b =>
    b.addEventListener('click', async e => {
      e.stopPropagation();
      const vid = +b.dataset.rm;
      const hasRecords = await db.sessions.where('aracId').equals(vid).count();
      if (hasRecords) {
        // kayıtlar korunur: silmek yerine arşivle
        await db.vehicles.update(vid, {archived: true});
        toast(t('archivedToast'));
      } else if (confirm(t('deleteAsk'))) {
        await db.vehicles.delete(vid);
      }
      if (S.defaultVehicleId === vid) {
        const rest = (await db.vehicles.toArray()).filter(v => !v.archived);
        S.defaultVehicleId = rest[0]?.id || null;
        await saveSetting('defaultVehicleId', S.defaultVehicleId);
      }
      renderVehiclePage();
    }));
  // 🛣️ butonu → kilometre güncelle
  $('set-vehicles').querySelectorAll('[data-odo]').forEach(li =>
    li.addEventListener('click', async e => {
      e.stopPropagation();
      const v = allV.find(x => x.id === +li.dataset.odo);
      if (!v) return;
      const cur = v.kmNow ? Math.round(distDisp(v.kmNow)) : '';
      const inp = prompt(t('odoPrompt', {u: S.unit}), cur);
      if (inp == null) return;
      const val = pf(inp);
      if (isNaN(val) || val < 0) return;
      const km = Math.round(S.unit === 'mi' ? val * MI : val);
      const upd = {kmNow: km};
      const sDef = v.kmStart != null ? Math.round(distDisp(v.kmStart)) : Math.round(distDisp(km));
      const sIn = prompt(t('odoStartPrompt', {u: S.unit}), sDef);
      if (sIn != null) {
        const sVal = pf(sIn);
        if (!isNaN(sVal) && sVal >= 0)
          upd.kmStart = Math.round(S.unit === 'mi' ? sVal * MI : sVal);
      }
      if (upd.kmStart == null) upd.kmStart = v.kmStart ?? km;
      // ters girilmişse (başlangıç > güncel) yer değiştir
      if (upd.kmStart > upd.kmNow) [upd.kmStart, upd.kmNow] = [upd.kmNow, upd.kmStart];
      await db.vehicles.update(v.id, upd);
      toast(t('odoSaved'));
      renderVehiclePage();
    }));

  // ---- Araç giderleri (araç filtreli) ----
  const wrapVehExp = $('wrap-veh-exp');
  wrapVehExp.style.display = vehicles.length > 1 ? '' : 'none';
  if (vehicles.length > 1) {
    const cur = S.vehExpVeh;
    $('veh-exp-sel').innerHTML = `<option value="">${t('allVehicles')}</option>` +
      vehicles.map(v => `<option value="${v.id}">${esc(vehName(v))}</option>`).join('');
    $('veh-exp-sel').value = cur;
  }
  const expVehName = S.vehExpVeh
    ? vehName(vehicles.find(v => String(v.id) === S.vehExpVeh))
    : (vehicles.length === 1 ? vehName(vehicles[0]) : '');
  $('c-exp-title').textContent = t('expenses') + (expVehName ? ' — ' + expVehName : '');
  const exAllV = await db.expenses.toArray();
  const ex = S.vehExpVeh
    ? exAllV.filter(e => String(e.aracId) === S.vehExpVeh || !e.aracId)
    : exAllV;

  // ---- toplam gider metrikleri (şarj + sabit) ----
  const sessV = vehFilter(await db.sessions.toArray(), S.vehExpVeh);
  const chargeTot = sessV.reduce((s, r) => s + amtB(r), 0);
  const fixedTot = ex.reduce((s, e) => s + expB(e), 0);
  $('v-total-cost').textContent = money(chargeTot + fixedTot);
  $('v-exp-total').textContent = money(fixedTot);

  // ---- sabit gider grafiği (Ay/Yıl) ----
  const gran = S.vehExpGran || 'month';
  $('v-exp-gran').querySelectorAll('button').forEach(b =>
    b.classList.toggle('sel', b.dataset.v === gran));
  $('v-exp-chart-wrap').style.display = ex.length ? '' : 'none';
  if (ex.length) {
    const now = new Date();
    const ebars = [];
    if (gran === 'year') {
      for (let i = 4; i >= 0; i--) {
        const y = String(now.getFullYear() - i);
        ebars.push({label: y,
          sum: ex.filter(e => e.tarih.slice(0, 4) === y).reduce((s, e) => s + expB(e), 0)});
      }
    } else {
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
        ebars.push({label: MONTHS[S.lang][d.getMonth()].slice(0, 3),
          sum: ex.filter(e => e.tarih.slice(0, 7) === key).reduce((s, e) => s + expB(e), 0)});
      }
    }
    const maxE = Math.max(1, ...ebars.map(b => b.sum));
    $('v-exp-chart').innerHTML = ebars.map(b =>
      `<div class="mb">
        <div class="amt">${b.sum ? money(b.sum) : ''}</div>
        <div class="bar" style="height:${6 + Math.round(b.sum / maxE * 66)}px"></div>
        <div class="m">${b.label}</div>
      </div>`).join('');
  }

  const expList = $('c-exp-list');
  if (!ex.length) {
    expList.innerHTML = `<div class="about" style="margin:0">${t('noExpenses')}</div>`;
    $('c-exp-cats-wrap').style.display = 'none';
  } else {
    const sortedExp = [...ex].sort((a, b) => b.tarih.localeCompare(a.tarih));
    expList.innerHTML = sortedExp.map(e => `
      <div class="crow" data-exp="${e.id}" style="cursor:pointer">
        <div class="avatar" style="background:var(--chip);color:var(--accent-text)">${EXP_ICON[e.tur] || '📦'}</div>
        <div class="mid">
          <div class="name">${e.altAd ? esc(e.altAd) : t('exp_' + e.tur)}</div>
          <div class="sub">${shortDate(e.tarih + 'T00:00')}${e.not ? ' · ' + esc(e.not) : ''}</div>
        </div>
        <div class="right"><div class="amt">${fm(symOf(e.cur || S.currency), Math.round(e.tutar).toLocaleString('tr-TR'))}</div></div>
      </div>`).join('');
    expList.querySelectorAll('[data-exp]').forEach(el =>
      el.addEventListener('click', async () =>
        openExpense(await db.expenses.get(+el.dataset.exp))));
    // "Diğer" türünde özel başlık (altAd) girilmişse kendi kategorisi gibi ayrı gösterilir
    const byCat = {};
    ex.forEach(e => {
      const key = (e.tur === 'other' && e.altAd) ? 'other:' + e.altAd.toLowerCase() : e.tur;
      (byCat[key] ||= {label: (e.tur === 'other' && e.altAd) ? e.altAd : t('exp_' + e.tur), icon: EXP_ICON[e.tur] || '📦', sum: 0});
      byCat[key].sum += expB(e);
    });
    const cats = Object.values(byCat).sort((a, b) => b.sum - a.sum);
    const maxC = Math.max(1, ...cats.map(c => c.sum));
    $('c-exp-cats-wrap').style.display = '';
    $('c-exp-cats').innerHTML = cats.map(c => `
      <div class="tl">
        <div class="tn">${c.icon} ${esc(c.label)}</div>
        <div class="tbar"><div style="width:${Math.round(c.sum / maxC * 100)}%"></div></div>
        <div class="tv">${money(c.sum)}</div>
      </div>`).join('');
  }
}
$('veh-exp-sel').addEventListener('change', () => {
  S.vehExpVeh = $('veh-exp-sel').value;
  renderVehiclePage();
});
$('v-exp-gran').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  S.vehExpGran = b.dataset.v;
  renderVehiclePage();
});
let photoTargetVid = null;
$('car-photo').addEventListener('change', async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const dataUrl = await resizePhoto(file);
    if (photoTargetVid) {
      await db.vehicles.update(photoTargetVid, {photo: dataUrl});
      photoTargetVid = null;
      toast(t('photoAdded'));
      renderVehiclePage();
    } else if (carPick) {
      carPick.photo = dataUrl;
      $('car-summary').innerHTML = evSummaryHTML(carPick) + photoBtnHTML(true);
      bindPhotoBtn();
    }
  } catch { /* okunamadı */ }
});

$('set-currency').addEventListener('change', async e => {
  S.currency = e.target.value;
  await saveSetting('currency', S.currency);
  applyI18n(); renderSettings();
});
$('set-unit').addEventListener('click', async e => {
  const b = e.target.closest('button'); if (!b) return;
  S.unit = b.dataset.v;
  await saveSetting('unit', S.unit);
  applyI18n(); renderSettings();
});
$('set-lang').addEventListener('change', async e => {
  S.lang = e.target.value;
  await saveSetting('lang', S.lang);
  applyI18n(); renderSettings();
});
$('set-theme').addEventListener('click', async e => {
  const b = e.target.closest('button'); if (!b) return;
  S.theme = b.dataset.v;
  await saveSetting('theme', S.theme);
  applyTheme();
  $('set-theme').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  renderSettings();
});
$('set-adv').addEventListener('change', async e => {
  S.advOpen = e.target.checked;
  await saveSetting('advOpen', S.advOpen);
});

// ---------- ülke seçici (ayarlar) ----------
function renderCountryList(query) {
  const q = (query || '').toLocaleLowerCase('tr');
  const list = COUNTRIES.filter(c =>
    c[2].toLocaleLowerCase('tr').includes(q) || c[0].toLowerCase().includes(q));
  const box = $('country-list');
  box.innerHTML = list.map(c =>
    `<div class="country-item ${c[0] === S.country ? 'sel' : ''}" data-code="${c[0]}">
      <div class="flag">${c[1]}</div>
      <div class="n">${esc(c[2])}</div>
      <div class="c">${c[3]} · ${c[5]}</div>
    </div>`).join('');
  box.querySelectorAll('.country-item').forEach(el =>
    el.addEventListener('click', async () => {
      const c = COUNTRIES.find(x => x[0] === el.dataset.code);
      if (countryPickMode === 'bank') {
        const codes = S.bankCountries && S.bankCountries.length ? [...S.bankCountries] : [S.country];
        if (!codes.includes(c[0])) codes.push(c[0]);
        S.bankCountries = codes;
        await saveSetting('bankCountries', codes);
        $('page-country').classList.remove('active');
        renderBankCountries();
        return;
      }
      S.country = c[0]; S.currency = c[3]; S.unit = c[5];
      if (LANG_NAMES[c[6]]) S.lang = c[6];
      for (const [k, v] of [['country', S.country], ['currency', S.currency], ['unit', S.unit], ['lang', S.lang]])
        await saveSetting(k, v);
      $('page-country').classList.remove('active');
      applyI18n(); renderSettings();
    }));
}
let countryPickMode = 'region';   // 'region' | 'bank'
$('btn-country').addEventListener('click', () => {
  countryPickMode = 'region';
  $('country-search').value = '';
  renderCountryList('');
  $('page-country').classList.add('active');
});
$('btn-add-bankc').addEventListener('click', () => {
  countryPickMode = 'bank';
  $('country-search').value = '';
  renderCountryList('');
  $('page-country').classList.add('active');
});
function renderBankCountries() {
  const codes = (S.bankCountries && S.bankCountries.length) ? S.bankCountries : [S.country];
  $('set-bankc').innerHTML = codes.map(cc => {
    const c = COUNTRIES.find(x => x[0] === cc);
    return `<button type="button" class="chip" data-cc="${cc}">${c ? c[1] + ' ' + c[2] : cc} ×</button>`;
  }).join('');
  $('set-bankc').querySelectorAll('button').forEach(b =>
    b.addEventListener('click', async () => {
      let codes2 = (S.bankCountries || [S.country]).filter(x => x !== b.dataset.cc);
      if (!codes2.length) codes2 = [S.country];
      S.bankCountries = codes2;
      await saveSetting('bankCountries', codes2);
      renderBankCountries();
    }));
}
$('btn-close-country').addEventListener('click', () => $('page-country').classList.remove('active'));
$('country-search').addEventListener('input', e => renderCountryList(e.target.value));

// ---------- araç arama (ortak) ----------
function searchEV(q) {
  q = (q || '').toLocaleLowerCase('tr').trim();
  if (q.length < 2) return [];
  return EV_DB
    .map((e, i) => ({i, brand: e[0], model: e[1], trim: e[2], y1: e[3], y2: e[4],
      batt: e[5], arch: e[6], dc: e[7], ac: e[8], range: e[9], body: e[10]}))
    .filter(v => (v.brand + ' ' + v.model + ' ' + v.trim).toLocaleLowerCase('tr').includes(q))
    .slice(0, 14);
}
function photoBtnHTML(has) {
  return `<button class="photo-btn" id="btn-carphoto" type="button">${t(has ? 'changePhoto' : 'addPhoto')}</button>`;
}
function bindPhotoBtn() {
  const b = $('btn-carphoto');
  if (b) b.addEventListener('click', () => { photoTargetVid = null; $('car-photo').click(); });
}
function bindEVSearch(inputId, resultsId, summaryId, onSel, withPhoto) {
  $(inputId).addEventListener('input', () => {
    const res = searchEV($(inputId).value);
    onSel(null);
    $(summaryId).style.display = 'none';
    const box = $(resultsId);
    const qv = $(inputId).value.trim();
    if (!res.length && qv.length >= 2) {
      box.innerHTML = `<button class="chip" style="align-self:flex-start" id="${resultsId}-custom">${t('customAdd', {q: esc(qv)})}</button>`;
      $(resultsId + '-custom').addEventListener('click', () => {
        const custom = {ad: qv, body: 'suv'};
        $(summaryId).innerHTML = evSummaryHTML(custom) + (withPhoto ? photoBtnHTML(false) : '');
        $(summaryId).style.display = '';
        if (withPhoto) bindPhotoBtn();
        onSel(custom);
        box.innerHTML = '';
      });
      return;
    }
    box.innerHTML = res.map(v => {
      const yr = v.y1 + (v.y2 ? '–' + v.y2 : '+');
      return `<div class="ev-item" data-i="${v.i}">
        <div class="n">${esc(v.brand)} ${esc(v.model)}</div>
        <div class="d">${esc(v.trim)} · ${yr} · ${v.batt} kWh · ${v.arch}V</div>
      </div>`;
    }).join('');
    box.querySelectorAll('.ev-item').forEach(el =>
      el.addEventListener('click', () => {
        box.querySelectorAll('.ev-item').forEach(x =>
          x.classList.toggle('sel', x === el));
        const e = EV_DB[+el.dataset.i];
        const v = {brand: e[0], model: e[1], trim: e[2], y1: e[3], y2: e[4],
          batt: e[5], arch: e[6], dc: e[7], ac: e[8], range: e[9], body: e[10]};
        $(summaryId).innerHTML = evSummaryHTML(v) + (withPhoto ? photoBtnHTML(false) : '');
        $(summaryId).style.display = '';
        if (withPhoto) bindPhotoBtn();
        onSel(v);
      }));
  });
}

// ---------- ayarlardan araç ekleme ----------
let carPick = null;
bindEVSearch('car-search', 'car-results', 'car-summary', v => {
  carPick = v;
  $('car-save').disabled = !v;
}, true);
$('btn-add-vehicle').addEventListener('click', () => {
  $('car-search').value = ''; $('car-results').innerHTML = '';
  $('car-summary').style.display = 'none'; carPick = null;
  $('car-save').disabled = true;
  $('page-addcar').classList.add('active');
});
$('btn-close-addcar').addEventListener('click', () => $('page-addcar').classList.remove('active'));
$('car-save').addEventListener('click', async () => {
  if (!carPick) return;
  const id = await db.vehicles.add(vehicleRec(carPick));
  if (!S.defaultVehicleId) { S.defaultVehicleId = id; await saveSetting('defaultVehicleId', id); }
  toast(t('vehicleAdded'));
  $('page-addcar').classList.remove('active');
  renderVehiclePage();
});
function vehicleRec(v) {
  const rec = v.brand
    ? {ad: v.brand + ' ' + v.model, brand: v.brand, model: v.model, trim: v.trim,
       y1: v.y1, y2: v.y2, batt: v.batt, arch: v.arch, dc: v.dc, ac: v.ac,
       range: v.range, body: v.body}
    : {ad: v.ad, body: v.body || 'suv'};
  if (v.photo) rec.photo = v.photo;
  return rec;
}

// ============================================================
// KAYIT FORMU
// ============================================================
let editingId = null;
$('nav-plus').addEventListener('click', () => openAdd());
$('btn-close-add').addEventListener('click', () => $('page-add').classList.remove('active'));
$('btn-adv').addEventListener('click', () => {
  $('adv-fields').classList.toggle('open');
  $('btn-adv').textContent =
    $('adv-fields').classList.contains('open') ? t('advancedHide') : t('advanced');
});
$('in-free').addEventListener('change', () => {
  const free = $('in-free').checked;
  $('wrap-paid').style.display = free ? 'none' : '';
  $('wrap-disc').style.display = free ? 'none' : '';
});
$('in-tip').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  $('in-tip').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
});
$('in-disc-type').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  $('in-disc-type').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  updateNetLine();
});
function updateNetLine() {
  const g = pf($('in-amount').value);
  const code = $('in-country').value;
  const c = COUNTRIES.find(x => x[0] === code);
  if (isNaN(g) || g < 0) { $('calc-net').textContent = '—'; return; }
  const type = $('in-disc-type').querySelector('.sel').dataset.v;
  const net = netFromGross(g, type, pf($('in-disc-val').value) || 0);
  $('calc-net').textContent = fm(symOf(c ? c[3] : S.currency),
    net.toLocaleString('tr-TR', {maximumFractionDigits: 2}));
}
['in-amount', 'in-disc-val'].forEach(id => $(id).addEventListener('input', updateNetLine));
// kWh kutuları: yalnız rakam, tam=3 / ondalık=2 hane
$('in-kwh-int').addEventListener('input', () => {
  $('in-kwh-int').value = $('in-kwh-int').value.replace(/\D/g, '').slice(0, 3);
});
$('in-kwh-dec').addEventListener('input', () => {
  $('in-kwh-dec').value = $('in-kwh-dec').value.replace(/\D/g, '').slice(0, 2);
});
$('in-firm').addEventListener('change', () => {
  $('in-firm-other').style.display = $('in-firm').value === '__other' ? '' : 'none';
});
$('in-country').addEventListener('change', () => formCountryChanged());
$('in-bank').addEventListener('change', async () => {
  if ($('in-bank').value !== '__newbank') return;
  const name = (prompt(t('newBankPrompt')) || '').trim();
  if (name) {
    S.customBanks = [...new Set([name, ...(S.customBanks || [])])].slice(0, 20);
    await saveSetting('customBanks', S.customBanks);
    $('in-bank').innerHTML = bankOptions();
    $('in-bank').value = name;
  } else {
    $('in-bank').value = '';
  }
});
$('btn-gps').addEventListener('click', () => {
  if (!navigator.geolocation) return toast(t('gpsFail'));
  $('btn-gps').textContent = '…';
  navigator.geolocation.getCurrentPosition(async p => {
    const {latitude: lat, longitude: lon} = p.coords;
    // 1) semt/mahalle adı (OpenStreetMap Nominatim)
    const place = await reverseGeo(lat, lon);
    $('in-loc').value = place || (lat.toFixed(5) + ', ' + lon.toFixed(5));
    // 2) yakındaki şarj istasyonları (Open Charge Map) — çip olarak öner
    const st = await nearbyStations(lat, lon);
    $('loc-chips').innerHTML = st.map(s =>
      `<button type="button" class="chip" data-n="${esc(s)}">${esc(s)}</button>`).join('');
    $('loc-chips').querySelectorAll('button').forEach(b =>
      b.addEventListener('click', () => { $('in-loc').value = b.dataset.n; }));
    $('btn-gps').textContent = '📍';
  }, () => { toast(t('gpsFail')); $('btn-gps').textContent = '📍'; },
  {timeout: 8000, maximumAge: 60000});
});
async function reverseGeo(lat, lon) {
  try {
    const ctrl = new AbortController();
    const tm = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=jsonv2&zoom=16&accept-language=${S.lang}`,
      {signal: ctrl.signal, headers: {'Accept': 'application/json'}});
    clearTimeout(tm);
    if (!res.ok) return null;
    const a = (await res.json()).address || {};
    const narrow = a.neighbourhood || a.suburb || a.quarter || a.village || a.hamlet;
    const town = a.town || a.city || a.county || '';
    return narrow ? (narrow + (town ? ', ' + town : '')) : (town || null);
  } catch { return null; }
}
async function nearbyStations(lat, lon) {
  try {
    const ctrl = new AbortController();
    const tm = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(`https://api.openchargemap.io/v3/poi/?output=json&latitude=${lat}&longitude=${lon}&distance=1&distanceunit=km&maxresults=4&compact=true&verbose=false`,
      {signal: ctrl.signal});
    clearTimeout(tm);
    if (!res.ok) return [];
    const j = await res.json();
    return (j || []).map(p => {
      const op = p.OperatorInfo && p.OperatorInfo.Title ? p.OperatorInfo.Title + ' — ' : '';
      return (op + (p.AddressInfo?.Title || '')).slice(0, 60);
    }).filter(Boolean);
  } catch { return []; }
}

function fillFirmSelect(code, current, usedCounts) {
  const used = Object.entries(usedCounts)
    .sort((a, b) => b[1] - a[1]).map(e => e[0]);
  const home = t('homeChip');
  const list = [...new Set([home, ...used, ...chargersFor(code)])];
  const opts = list.map(f => `<option value="${esc(f)}">${esc(f)}</option>`).join('') +
    `<option value="__other">${t('other')}</option>`;
  $('in-firm').innerHTML = opts;
  if (current && list.includes(current)) {
    $('in-firm').value = current;
    $('in-firm-other').style.display = 'none';
  } else if (current) {
    $('in-firm').value = '__other';
    $('in-firm-other').value = current;
    $('in-firm-other').style.display = '';
  } else {
    $('in-firm').value = used[0] || list[1] || home;
    $('in-firm-other').style.display = 'none';
  }
}

async function formCountryChanged(keepRate) {
  const code = $('in-country').value;
  const c = COUNTRIES.find(x => x[0] === code);
  const all = await db.sessions.toArray();
  const counts = {};
  all.forEach(r => { if ((r.ulke || S.country) === code) counts[r.firma] = (counts[r.firma] || 0) + 1; });
  const curFirm = $('in-firm').value === '__other'
    ? $('in-firm-other').value.trim()
    : $('in-firm').value;
  fillFirmSelect(code, curFirm && curFirm !== t('other') ? curFirm : '', counts);
  $('in-bank').innerHTML = bankOptions();
  $('in-amount-lbl').textContent = t('amount', {s: symOf(c[3])});

  // döviz kuru alanı
  const foreign = c[3] !== S.currency;
  $('wrap-rate').style.display = foreign ? '' : 'none';
  if (foreign) {
    $('rate-lbl').textContent = t('rateLbl', {f: c[3], b: S.currency});
    $('rate-note').textContent = t('rateNote', {b: S.currency});
    if (!keepRate) {
      $('in-rate').value = '';
      const got = await fetchRate(c[3], S.currency, $('in-date').value);
      if (got && $('in-country').value === code) {
        $('in-rate').value = String(Math.round(got.rate * 10000) / 10000).replace('.', ',');
        $('rate-note').textContent = t('rateAuto', {d: got.date}) + ' — ' + t('rateNote', {b: S.currency});
      }
    }
  }
}

async function openAdd(id) {
  editingId = id || null;
  const r = id ? await db.sessions.get(id) : null;
  $('add-title').textContent = t(id ? 'editTitle' : 'addTitle');
  $('form-err').classList.remove('show');

  const selCode = r?.ulke || S.country;
  $('in-country').innerHTML = COUNTRIES.map(c =>
    `<option value="${c[0]}" ${c[0] === selCode ? 'selected' : ''}>${c[1]} ${c[2]} (${c[3]})</option>`).join('');

  $('in-date').value = r ? r.tarih.slice(0, 10) : new Date().toISOString().slice(0, 10);
  $('in-tip').querySelectorAll('button').forEach(b =>
    b.classList.toggle('sel', b.dataset.v === (r?.tip || 'DC')));

  // kWh: tam + ondalık kutuları
  const kwh = r?.kwh ?? '';
  $('in-kwh-int').value = (kwh === '' || !kwh) ? '' : Math.floor(kwh);
  $('in-kwh-dec').value = (kwh === '' || !kwh) ? ''
    : String(Math.round((kwh - Math.floor(kwh)) * 100)).padStart(2, '0');
  $('in-dist').value = r?.mesafeKm ? Math.round(distDisp(r.mesafeKm)) : '';
  $('in-free').checked = !!r?.free;
  const grossVal = r && !r.free
    ? (r.tutar != null ? r.tutar : (r.odenen || 0) + savingsOf(r)) : null;
  $('in-amount').value = grossVal != null && !isNaN(grossVal)
    ? String(Math.round(grossVal * 100) / 100).replace('.', ',') : '';
  const dt = r?.indirimTip === 'percent' ? 'percent' : 'amount';
  $('in-disc-type').querySelectorAll('button').forEach(b =>
    b.classList.toggle('sel', b.dataset.v === dt));
  $('in-disc-val').value = r?.indirimDeger ? String(r.indirimDeger).replace('.', ',') : '';
  const durMin = r?.dur || 0;
  $('in-dur-h').value = durMin ? Math.floor(durMin / 60) : '';
  $('in-dur-m').value = durMin ? durMin % 60 : '';
  $('in-loc').value = r?.loc || '';
  $('in-socb').value = r?.socB ?? '';
  $('in-soca').value = r?.socA ?? '';
  $('in-note').value = r?.not || '';
  $('in-rate').value = r?.rate ? String(r.rate).replace('.', ',') : '';
  $('in-free').dispatchEvent(new Event('change'));

  // firma / banka / kur — ülkeye göre (düzenlemede firmayı koru)
  await (async () => {
    const all = await db.sessions.toArray();
    const counts = {};
    all.forEach(x => { if ((x.ulke || S.country) === selCode) counts[x.firma] = (counts[x.firma] || 0) + 1; });
    fillFirmSelect(selCode, r?.firma || '', counts);
    $('in-bank').innerHTML = bankOptions();
    $('in-bank').value = r?.banka || '';
    const c = COUNTRIES.find(x => x[0] === selCode);
    $('in-amount-lbl').textContent = t('amount', {s: symOf(c[3])});
    const foreign = c[3] !== S.currency;
    $('wrap-rate').style.display = foreign ? '' : 'none';
    if (foreign) {
      $('rate-lbl').textContent = t('rateLbl', {f: c[3], b: S.currency});
      $('rate-note').textContent = t('rateNote', {b: S.currency});
      if (!r?.rate) formCountryChanged();
    }
  })();

  // lokasyon önerileri (daha önce girilenler)
  const locs = [...new Set((await db.sessions.toArray()).map(x => x.loc).filter(Boolean))];
  $('loc-list').innerHTML = locs.map(l => `<option value="${esc(l)}">`).join('');

  // indirim ve SoC hızlı çipleri
  $('disc-chips').innerHTML = [0, 10, 15, 20, 30].map(v =>
    `<button type="button" class="chip" data-v="${v}">${v}%</button>`).join('');
  $('disc-chips').querySelectorAll('button').forEach(b =>
    b.addEventListener('click', () => {
      $('in-disc-type').querySelectorAll('button').forEach(x =>
        x.classList.toggle('sel', x.dataset.v === 'percent'));
      $('in-disc-val').value = b.dataset.v;
    }));
  $('soc-chips').innerHTML = ['20-80','10-80','10-90','20-100','10-100','0-100'].map(v =>
    `<button type="button" class="chip" data-v="${v}">${v}</button>`).join('');
  $('soc-chips').querySelectorAll('button').forEach(b =>
    b.addEventListener('click', () => {
      const [a, c2] = b.dataset.v.split('-');
      $('in-socb').value = a; $('in-soca').value = c2;
    }));

  // araç seçimi (arşivdekiler hariç; düzenlenen kayıt arşivli araca aitse o da listelenir)
  let vehicles = (await db.vehicles.toArray()).filter(v => !v.archived || v.id === r?.aracId);
  $('wrap-vehicle').style.display = vehicles.length > 1 ? '' : 'none';
  $('in-vehicle').innerHTML = vehicles.map(v =>
    `<option value="${v.id}">${esc(vehName(v))}</option>`).join('');
  $('in-vehicle').value = r?.aracId ?? S.defaultVehicleId ?? (vehicles[0]?.id || '');

  const advOpen = S.advOpen || !!(r && (r.dur || r.loc || r.not || r.banka));
  $('adv-fields').classList.toggle('open', advOpen);
  $('btn-adv').textContent = advOpen ? t('advancedHide') : t('advanced');

  $('page-add').classList.add('active');
  $('page-add').querySelector('.ov-body').scrollTop = 0;
}

$('btn-save').addEventListener('click', async () => {
  const firmSel = $('in-firm').value;
  const firma = firmSel === '__other' ? $('in-firm-other').value.trim() : firmSel;
  const kInt = parseInt($('in-kwh-int').value) || 0;
  const kDec = Math.min(99, parseInt($('in-kwh-dec').value) || 0);
  const kwh = kInt + kDec / 100;
  const free = $('in-free').checked;
  const amount = free ? 0 : pf($('in-amount').value);
  if (!firma || kwh <= 0 || (!free && (isNaN(amount) || amount < 0))) {
    $('form-err').textContent = t('formError');
    $('form-err').classList.add('show');
    return;
  }
  const code = $('in-country').value;
  const c = COUNTRIES.find(x => x[0] === code);
  const foreign = c[3] !== S.currency;
  const rate = pf($('in-rate').value);
  if (foreign && (isNaN(rate) || rate <= 0)) {
    $('form-err').textContent = t('rateNeeded');
    $('form-err').classList.add('show');
    return;
  }
  const distIn = pf($('in-dist').value) || 0;
  const discVal = free ? 0 : (pf($('in-disc-val').value) || 0);
  const discType = $('in-disc-type').querySelector('.sel').dataset.v;
  const gross = free ? 0 : Math.round(amount * 100) / 100;
  const net = free ? 0 : Math.round(netFromGross(gross, discType, discVal) * 100) / 100;
  let a = parseInt($('in-socb').value), b = parseInt($('in-soca').value);
  if (!isNaN(a) && !isNaN(b) && a > b) [a, b] = [b, a];
  const durH = parseInt($('in-dur-h').value) || 0;
  const durM = parseInt($('in-dur-m').value) || 0;
  const rec = {
    tarih: $('in-date').value + 'T12:00',
    tip: $('in-tip').querySelector('.sel').dataset.v,
    firma, kwh: Math.round(kwh * 100) / 100,
    tutar: gross,
    odenen: net,
    indirim: Math.round((gross - net) * 100) / 100,
    free,
    indirimTip: discVal > 0 ? discType : 'none',
    indirimDeger: discVal,
    banka: discVal > 0 || $('in-bank').value ? $('in-bank').value : '',
    mesafeKm: distIn ? Math.round((S.unit === 'mi' ? distIn * MI : distIn) * 10) / 10 : null,
    dur: (durH * 60 + durM) || null,
    loc: $('in-loc').value.trim(),
    socB: isNaN(a) ? null : a, socA: isNaN(b) ? null : b,
    ulke: code, cur: c[3],
    rate: foreign ? rate : null,
    rateBase: foreign ? S.currency : null,
    aracId: parseInt($('in-vehicle').value) || null,
    not: $('in-note').value.trim()
  };
  let recId;
  if (editingId) {
    const oldRec = await db.sessions.get(editingId);
    await db.sessions.update(editingId, rec);
    recId = editingId;
    await bumpVehicleKm(rec.aracId, (rec.mesafeKm || 0) - (oldRec?.mesafeKm || 0));
    toast(t('updated'));
  } else {
    recId = await db.sessions.add(rec);
    await bumpVehicleKm(rec.aracId, rec.mesafeKm || 0);
    toast(t('saved'));
  }
  $('page-add').classList.remove('active');
  showScreen(screen);
  // kur tablosunu sessizce ekle (çift yönlü dönüşüm için — yerli kayıt dahil)
  fetchTable(c[3], rec.tarih.slice(0, 10)).then(got => {
    if (got) db.sessions.update(recId, {fxTable: got.rates, fxDate: got.date})
      .then(() => { if (screen === 'dashboard') renderDashboard(); });
  });
});

// ============================================================
// ARAÇ GİDERLERİ (vergi / sigorta / bakım …)
// ============================================================
let editingExpId = null;
async function openExpense(rec) {
  editingExpId = rec?.id || null;
  $('exp-title').textContent = rec ? t('editExpense') : t('addExpense');
  $('btn-del-exp').style.display = rec ? '' : 'none';
  $('in-exp-type').innerHTML = EXP_TYPES.map(k =>
    `<option value="${k}">${EXP_ICON[k]} ${t('exp_' + k)}</option>`).join('');
  const curs = [...new Set(COUNTRIES.map(x => x[3]))].sort();
  $('in-exp-cur').innerHTML = curs.map(k =>
    `<option value="${k}">${k} (${symOf(k)})</option>`).join('');
  const vs = (await db.vehicles.toArray()).filter(v => !v.archived || v.id === rec?.aracId);
  $('wrap-exp-veh').style.display = vs.length > 1 ? '' : 'none';
  $('in-exp-veh').innerHTML = `<option value="">${t('allVehicles')}</option>` +
    vs.map(v => `<option value="${v.id}">${esc(vehName(v))}</option>`).join('');
  $('in-exp-type').value = rec?.tur || 'tax';
  $('in-exp-altad').placeholder = t('otherTypePh');
  $('in-exp-altad').value = rec?.altAd || '';
  $('in-exp-altad').style.display = $('in-exp-type').value === 'other' ? '' : 'none';
  $('in-exp-date').value = (rec?.tarih || new Date().toISOString()).slice(0, 10);
  $('in-exp-cur').value = rec?.cur || S.currency;
  $('in-exp-amount').value = rec ? String(rec.tutar).replace('.', ',') : '';
  $('in-exp-veh').value = rec?.aracId || '';
  $('in-exp-note').value = rec?.not || '';
  $('in-exp-amt-lbl').textContent = t('expAmount') + ' (' + symOf($('in-exp-cur').value) + ')';
  $('page-expense').classList.add('active');
}
$('btn-add-exp').addEventListener('click', () => openExpense(null));
$('in-exp-type').addEventListener('change', () => {
  $('in-exp-altad').style.display = $('in-exp-type').value === 'other' ? '' : 'none';
});
$('in-exp-cur').addEventListener('change', () => {
  $('in-exp-amt-lbl').textContent = t('expAmount') + ' (' + symOf($('in-exp-cur').value) + ')';
});
$('btn-close-exp').addEventListener('click', () => $('page-expense').classList.remove('active'));
$('btn-del-exp').addEventListener('click', async () => {
  if (!editingExpId || !confirm(t('deleteAsk'))) return;
  await db.expenses.delete(editingExpId);
  $('page-expense').classList.remove('active');
  editingExpId = null;
  toast(t('deleted'));
  renderVehiclePage();
  renderCompare();
});
$('btn-save-exp').addEventListener('click', async () => {
  const tutar = pf($('in-exp-amount').value);
  if (isNaN(tutar) || tutar <= 0) { toast(t('amountNeeded')); return; }
  const cur = $('in-exp-cur').value;
  const tur = $('in-exp-type').value;
  const rec = {
    tarih: $('in-exp-date').value || new Date().toISOString().slice(0, 10),
    tur,
    altAd: tur === 'other' ? $('in-exp-altad').value.trim() : '',
    tutar, cur,
    aracId: $('in-exp-veh').value ? +$('in-exp-veh').value : null,
    not: $('in-exp-note').value.trim()
  };
  const wasEditing = editingExpId;
  const id = wasEditing
    ? (await db.expenses.update(wasEditing, rec), wasEditing)
    : await db.expenses.add(rec);
  $('page-expense').classList.remove('active');
  toast(wasEditing ? t('updated') : t('saved'));
  editingExpId = null;
  renderVehiclePage();
  renderCompare();
  fetchTable(cur, rec.tarih).then(got => {
    if (got) db.expenses.update(id, {fxTable: got.rates, fxDate: got.date})
      .then(() => { renderVehiclePage(); renderCompare(); });
  });
});

// ============================================================
// ONBOARDING (kompakt: açılır listeler)
// ============================================================
let obEv = null;
function initOnboarding() {
  $('ob-country').innerHTML = COUNTRIES.map(c =>
    `<option value="${c[0]}">${c[1]} ${c[2]}</option>`).join('');
  $('ob-country').value = 'TR';
  const curs = [...new Set(COUNTRIES.map(x => x[3]))].sort();
  $('ob-currency').innerHTML = curs.map(k =>
    `<option value="${k}">${k} (${symOf(k)})</option>`).join('');
  $('ob-currency').value = 'TRY';
  $('ob-lang').innerHTML = Object.keys(LANG_NAMES).map(k =>
    `<option value="${k}">${LANG_NAMES[k]}</option>`).join('');
  $('ob-lang').value = S.lang;

  $('ob-country').addEventListener('change', () => {
    const c = COUNTRIES.find(x => x[0] === $('ob-country').value);
    $('ob-currency').value = c[3];
    $('ob-unit').querySelectorAll('button').forEach(b =>
      b.classList.toggle('sel', b.dataset.v === c[5]));
    if (LANG_NAMES[c[6]]) {
      $('ob-lang').value = c[6];
      S.lang = c[6];
      applyI18n();
    }
  });
  $('ob-lang').addEventListener('change', () => {
    S.lang = $('ob-lang').value;
    applyI18n();
  });
  $('ob-unit').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    $('ob-unit').querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  });
  $('ob-next').addEventListener('click', () => {
    $('ob-step1').style.display = 'none';
    $('ob-step2').style.display = '';
    $('obp2').classList.add('on');
  });
  $('ob-back').addEventListener('click', () => {
    $('ob-step2').style.display = 'none';
    $('ob-step1').style.display = '';
    $('obp2').classList.remove('on');
  });
  bindEVSearch('ob-ev-search', 'ob-ev-results', 'ob-ev-summary', v => {
    obEv = v;
    $('ob-done').disabled = !v;
    $('ob-km-wrap').style.display = v ? '' : 'none';
    // Araç seçilince arama kutusu ve sonuç listesi kapanır — km alanı öne çıkar
    $('ob-ev-search').style.display = v ? 'none' : '';
    $('ob-ev-results').style.display = v ? 'none' : '';
    $('ob-change-car').style.display = v ? '' : 'none';
  }, false);
  $('ob-change-car').addEventListener('click', () => {
    obEv = null;
    $('ob-done').disabled = true;
    $('ob-km-wrap').style.display = 'none';
    $('ob-ev-summary').style.display = 'none';
    $('ob-change-car').style.display = 'none';
    $('ob-ev-search').style.display = '';
    $('ob-ev-results').style.display = '';
    $('ob-ev-results').innerHTML = '';
    $('ob-ev-search').value = '';
    $('ob-km').value = '';
    $('ob-ev-search').focus();
  });
  $('ob-skip').addEventListener('click', () => finishOnboarding(false));
  $('ob-done').addEventListener('click', () => finishOnboarding(true));
}
async function finishOnboarding(withCar) {
  S.country = $('ob-country').value;
  S.currency = $('ob-currency').value;
  S.unit = $('ob-unit').querySelector('.sel').dataset.v;
  S.lang = $('ob-lang').value;
  S.onboarded = true;
  for (const [k, v] of [['country', S.country], ['currency', S.currency],
    ['unit', S.unit], ['lang', S.lang], ['onboarded', true]])
    await saveSetting(k, v);
  if (!S.bankCountries) { S.bankCountries = [S.country]; await saveSetting('bankCountries', S.bankCountries); }
  if (withCar && obEv) {
    const rec = vehicleRec(obEv);
    const kmIn = pf($('ob-km').value);
    if (!isNaN(kmIn) && kmIn > 0) {
      const km = S.unit === 'mi' ? kmIn * MI : kmIn;
      rec.kmStart = Math.round(km); rec.kmNow = Math.round(km);
    }
    const id = await db.vehicles.add(rec);
    S.defaultVehicleId = id;
    await saveSetting('defaultVehicleId', id);
  }
  $('ob').classList.remove('active');
  applyI18n();
  renderDashboard();
}

// ============================================================
// YEDEKLEME
// ============================================================
function today() { return new Date().toISOString().slice(0, 10); }
function download(content, name, type) {
  const blob = new Blob([content], {type});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
$('btn-export-json').addEventListener('click', async () => {
  const payload = {
    app: 'WattTrack', version: 8, exportedAt: new Date().toISOString(),
    sessions: await db.sessions.toArray(),
    vehicles: await db.vehicles.toArray(),
    expenses: await db.expenses.toArray(),
    settings: await db.settings.toArray()
  };
  download(JSON.stringify(payload, null, 2), `watttrack-yedek-${today()}.json`, 'application/json');
  toast(t('jsonDone'));
});
$('btn-export-csv').addEventListener('click', async () => {
  const rows = (await db.sessions.toArray()).sort((a, b) => a.tarih.localeCompare(b.tarih));
  const vehicles = await db.vehicles.toArray();
  const vn = id => { const v = vehicles.find(x => x.id === id); return v ? vehName(v) : ''; };
  const num = n => n == null ? '' : String(Math.round(n * 100) / 100).replace('.', ',');
  // CSV formül enjeksiyonuna karşı koruma: =,+,-,@ ile başlayan metinleri etkisizleştir
  const safe = s => {
    let v = (s || '').toString().replace(/;/g, ',').replace(/[\r\n]/g, ' ');
    if (/^[=+\-@]/.test(v)) v = "'" + v;
    return v;
  };
  const head = ['Tarih','Ulke','ParaBirimi','Kur','Firma','Tip','Ucretsiz','kWh','Odenen','OdenenTemel','Indirim','ListeTutar','BirimFiyat','Banka','MesafeKm','SureDk','SoCOnce','SoCSonra','Lokasyon','Arac','Not'];
  const lines = [head.join(';')];
  rows.forEach(r => {
    const sav = savingsOf(r);
    lines.push([
      r.tarih.slice(0, 10), r.ulke || '', r.cur || '', r.rate ? num(r.rate) : '',
      safe(r.firma), r.tip || '', r.free ? 1 : 0, num(r.kwh),
      num(r.odenen), num(amtB(r)), num(sav), num(r.odenen + sav),
      r.kwh ? num(r.odenen / r.kwh) : '', safe(r.banka),
      r.mesafeKm ? num(r.mesafeKm) : '', r.dur ?? '', r.socB ?? '', r.socA ?? '',
      safe(r.loc), safe(vn(r.aracId)), safe(r.not)
    ].join(';'));
  });
  download('\uFEFF' + lines.join('\r\n'), `watttrack-${today()}.csv`, 'text/csv;charset=utf-8');
  toast(t('csvDone'));
});
$('btn-import').addEventListener('click', () => $('file-import').click());
async function importBackupText(text) {
  {
    const data = JSON.parse(text);
    if (data.app !== 'WattTrack' || !Array.isArray(data.sessions)) throw 0;
    // mükerrer tespiti: tarih+firma+kwh+tutar+para birimi imzası
    const sig = r => [r.tarih, r.firma, r.kwh, r.odenen, r.cur || ''].join('|');
    const existing = new Set((await db.sessions.toArray()).map(sig));
    const fresh = [], dupes = [];
    data.sessions.forEach(({id, ...r}) => (existing.has(sig(r)) ? dupes : fresh).push(r));
    if (!fresh.length && data.sessions.length) {
      alert(t('importAllDup'));
      return;
    }
    const msg = dupes.length
      ? t('importPartial', {n: fresh.length, d: dupes.length})
      : fresh.length + ' ' + t('importAsk');
    if (!confirm(msg)) return;
    if (fresh.length) await db.sessions.bulkAdd(fresh);
    if (Array.isArray(data.expenses) && data.expenses.length) {
      const esig = e => [e.tarih, e.tur, e.tutar, e.cur || ''].join('|');
      const have = new Set((await db.expenses.toArray()).map(esig));
      const newEx = data.expenses.map(({id, ...e}) => e).filter(e => !have.has(esig(e)));
      if (newEx.length) await db.expenses.bulkAdd(newEx);
    }
    for (const {id, ...v} of (data.vehicles || [])) {
      if (!v.ad) continue;
      const ex = await db.vehicles.where('ad').equals(v.ad).first();
      if (!ex) { await db.vehicles.add(v); continue; }
      // aynı isimli araç varsa: yedekteki km/fotoğraf bilgisini birleştir
      const upd = {};
      if (v.kmStart != null) upd.kmStart = v.kmStart;
      if (v.kmNow != null && (ex.kmNow == null || v.kmNow > ex.kmNow || ex.kmStart === ex.kmNow))
        upd.kmNow = Math.max(v.kmNow, ex.kmNow || 0);
      if (v.photo && !ex.photo) upd.photo = v.photo;
      if (Object.keys(upd).length) await db.vehicles.update(ex.id, upd);
    }
    toast(dupes.length ? t('importPartial', {n: fresh.length, d: dupes.length}) : t('imported'));
    showScreen('dashboard');
  }
}
$('file-import').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try { await importBackupText(await file.text()); }
  catch { toast(t('importFail')); }
  e.target.value = '';
});
// PWA file_handlers: .json dosyası uygulamayla açılınca yedeği içe aktar
if ('launchQueue' in window) {
  window.launchQueue.setConsumer(async params => {
    if (!params.files || !params.files.length) return;
    try {
      const file = await params.files[0].getFile();
      await importBackupText(await file.text());
    } catch { toast(t('importFail')); }
  });
}
$('btn-rate').addEventListener('click', () => {
  window.open('https://play.google.com/store/apps/details?id=app.watttrack.twa', '_blank', 'noopener');
});
$('btn-support').addEventListener('click', () => {
  window.open('https://github.com/Rino-06/WattTrack', '_blank', 'noopener');
});
$('btn-wipe').addEventListener('click', async () => {
  if (!confirm(t('wipeAsk1')) || !confirm(t('wipeAsk2'))) return;
  await db.sessions.clear(); await db.vehicles.clear(); await db.settings.clear();
  toast(t('wiped'));
  location.reload();
});

// ============================================================
// BAŞLANGIÇ
// ============================================================
(async function init() {
  for (const key of ['country','currency','unit','lang','advOpen','defaultVehicleId','onboarded','cmp','bankCountries','customBanks','gran','theme']) {
    const row = await db.settings.get(key);
    if (row) S[key] = row.value;
  }
  initOnboarding();
  applyI18n();
  applyTheme();
  if (!S.onboarded) $('ob').classList.add('active');
  renderDashboard();
  // PWA kısayolları (?action=add | ?page=history/compare/settings)
  const q = new URLSearchParams(location.search);
  if (S.onboarded && (q.get('share_text') || q.get('share_title'))) {
    await openAdd();
    $('in-note').value = [q.get('share_title'), q.get('share_text'), q.get('share_url')]
      .filter(Boolean).join(' ').slice(0, 200);
    $('adv-fields').classList.add('open');
  }
  else if (S.onboarded && q.get('action') === 'add') openAdd();
  else if (S.onboarded && ['stats','history','compare','vehicle','settings'].includes(q.get('page')))
    showScreen(q.get('page'));
  backfillRates().then(() => { if (screen === 'dashboard') renderDashboard(); });
  hideSplash();
})();

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  });
  // güncelleme geldiğinde (yeni SW devraldığında) sayfayı bir kez tazele
  let swReloaded = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (swReloaded) return;
    swReloaded = true;
    location.reload();
  });
}
